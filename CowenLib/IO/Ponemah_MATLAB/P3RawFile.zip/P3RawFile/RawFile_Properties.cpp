
#include "stdafx.h"
#include <stdlib.h>
#include "P3RawFile.h"
#include "P3RawIncludes.h"


/// Get Start Time of Raw File.  If variable is NULL, it is ignored
HRESULT P3RawFile::GetFileTime(USHORT* pHours, USHORT* pMinutes, USHORT* pSeconds)
{
   if (!m_RawHeader.bValid)   RETURN_ERR( RAWERR_RAWHEADER_NOT_VALID );

   USHORT sHours, sMinutes, sSeconds;
   sHours = (USHORT) ((m_RawHeader.lTime & 0xff000000) >> 24);
   sMinutes = (USHORT) ((m_RawHeader.lTime & 0x00ff0000) >> 16);
   sSeconds = (USHORT) ((m_RawHeader.lTime & 0x0000ff00) >> 8);
   
   if (pHours)    *pHours = sHours;
   if (pMinutes)  *pMinutes = sMinutes;
   if (pSeconds)  *pSeconds = sSeconds;
   
   return S_OK;
}

/// Set File Time of Raw File.
HRESULT P3RawFile::SetFileTime(USHORT iHours, USHORT iMinutes, USHORT iSeconds)
{
   m_RawHeader.lTime = (iHours << 24) | (iMinutes << 16) | (iSeconds << 8);
   return S_OK;
}

/// Get Start Date of Raw File.  If variable is NULL, it is ignored
HRESULT P3RawFile::GetFileDate(ULONG* pYear, ULONG* pMonth, ULONG* pDay)
{
   if (!m_RawHeader.bValid)   RETURN_ERR( RAWERR_RAWHEADER_NOT_VALID );

   LONG iYear, iMonth, iDay;
   iYear = (int) ((m_RawHeader.lDate & 0xffff0000) >> 16);
   iMonth = (int) ((m_RawHeader.lDate & 0x0000ff00) >> 8);
   iDay = (int) (m_RawHeader.lDate & 0x000000ff);
   
   if (pYear)     *pYear = iYear;
   if (pMonth)    *pMonth = iMonth;
   if (pDay)      *pDay = iDay;
   
   return S_OK;
}

/// Set File Date of Raw File.
HRESULT P3RawFile::SetFileDate(ULONG iYear, ULONG iMonth, ULONG iDay)
{
   m_RawHeader.lDate = (iYear << 16) | (iMonth << 8) | (iDay);
   return S_OK;
}


/// Get Current Elapsed Time.  If variable is NULL, it is ignored
HRESULT P3RawFile::GetCurrentElapsedTime(USHORT* pHours, USHORT* pMinutes, USHORT* pSeconds, USHORT* pMilliSeconds)
{
   if (!m_RawHeader.bValid)   RETURN_ERR( RAWERR_RAWHEADER_NOT_VALID );

   USHORT sHours = (USHORT)(m_i64CurElapsedTime / 60 / 60 / NANO_FACTOR);
   USHORT sMinutes = (USHORT)( (m_i64CurElapsedTime / 60 / NANO_FACTOR) - (sHours * 60) );
   USHORT sSeconds = (USHORT)( (m_i64CurElapsedTime / NANO_FACTOR) - (sHours * 60 * 60) - (sMinutes * 60) );
   USHORT sTicks = (USHORT)( (m_i64CurElapsedTime - ((INT64)sHours * 60 * 60 * NANO_FACTOR) - ((INT64)sMinutes * 60 * NANO_FACTOR) - ((INT64)sSeconds * NANO_FACTOR) ) / DELTA_TICK_RES);

   if (pHours)          *pHours = sHours;
   if (pMinutes)        *pMinutes = sMinutes;
   if (pSeconds)        *pSeconds = sSeconds;
   if (pMilliSeconds)   *pMilliSeconds = sTicks;

   return S_OK;
}

/// Get Current Elapsed Time in Nanoseconds.
INT64 P3RawFile::GetCurrentNanoSeconds()
{
   if (!m_RawHeader.bValid)
      RETURN_ERR( RAWERR_RAWHEADER_NOT_VALID );

   return m_i64CurElapsedTime;
}


/// Get Current Real Time.  If variable is NULL, it is ignored
HRESULT P3RawFile::GetCurrentRealTime(USHORT* pHours, USHORT* pMinutes, USHORT* pSeconds, USHORT* pMilliSeconds)
{
   if (!m_RawHeader.bValid)   RETURN_ERR( RAWERR_RAWHEADER_NOT_VALID );

   // Get File Time
   WORD sHours, sMinutes, sSeconds;
   CHECK_RETURN( GetFileTime(&sHours, &sMinutes, &sSeconds) );

   // Get Elapsed time (and ticks)
   WORD sElpHours, sElpMinutes, sElpSeconds;
   CHECK_RETURN( GetCurrentElapsedTime(&sElpHours, &sElpMinutes, &sElpSeconds, pMilliSeconds) );

   // Add elapsed time to file time
   int iCarry = 0;

   sSeconds += sElpSeconds;
   iCarry = sSeconds / 60;
   sSeconds = sSeconds % 60;

   sMinutes += sElpMinutes + iCarry;
   iCarry = sMinutes / 60;
   sMinutes = sMinutes % 60;
   
   sHours += sElpHours + iCarry;
   iCarry = sHours / 24;
   sHours = sHours % 24;

   if (pHours)    *pHours = sHours;
   if (pMinutes)  *pMinutes = sMinutes;
   if (pSeconds)  *pSeconds = sSeconds;

   return S_OK;
}


/// Get Current Real Date.  If variable is NULL, it is ignored
HRESULT P3RawFile::GetCurrentRealDate(ULONG* pYear, ULONG* pMonth, ULONG* pDay)
{
   ULONG iYear, iMonth, iDay;
   CHECK_RETURN( GetFileDate(&iYear, &iMonth, &iDay) );

   // TODO: advance day based on elapsed time
   
   if (pYear)     *pYear = iYear;
   if (pMonth)    *pMonth = iMonth;
   if (pDay)      *pDay = iDay;

   return S_OK;
}

/// Get User Name.
void P3RawFile::GetUserName(char* pVal, int iCount)
{
   strncpy(pVal, m_RawHeader.szUserName, iCount);
}

/// Put User Name.
void P3RawFile::SetUserName(LPCTSTR newVal)
{
   strncpy(m_RawHeader.szUserName, newVal, USERNAME_LENGTH);
}

/// Get Master Sample Rate
float P3RawFile::GetSampleRate()
{
   return m_RawHeader.fRate;
}

/// Set Master Sample Rate (Changes Time Slice).
void P3RawFile::SetSampleRate(float newVal)
{
   m_RawHeader.fRate = newVal;
   m_RawHeader.i64TimeSlice = (INT64)(NANO_FACTOR / newVal);
}

/// Get Master Time Slice (Reciprical of Sample Rate).
INT64 P3RawFile::GetTimeSlice()
{
   return (ULONGLONG)(NANO_FACTOR / m_RawHeader.fRate);
}

/// Set Master Time Slice (Changes Sample Rate).
void P3RawFile::SetTimeSlice(INT64 newVal)
{
   m_RawHeader.fRate = ((float)((INT64)NANO_FACTOR)) / (float)newVal;
   m_RawHeader.i64TimeSlice = newVal;
}

/// CP Serial
USHORT P3RawFile::GetCPSerial()
{  return m_RawHeader.sCP_Serial;                 }
void P3RawFile::SetCPSerial(USHORT newVal)
{  m_RawHeader.sCP_Serial = newVal;               }

/// AD Serial
USHORT P3RawFile::GetADSerial()
{  return m_RawHeader.sAD_Serial;                 }
void P3RawFile::SetADSerial(USHORT newVal)
{  m_RawHeader.sAD_Serial = newVal;               }

/// Channel Count
USHORT P3RawFile::GetChannelCount()
{  return m_RawHeader.sNumChannels;                 }
void P3RawFile::SetChannelCount(USHORT newVal)
{  m_RawHeader.sNumChannels = newVal;               }

/// Channel Type
char P3RawFile::GetChanType(int iChan)
{  return m_RawHeader.acType[iChan];                 }
void P3RawFile::SetChanType(int iChan, char newVal)
{  m_RawHeader.acType[iChan] = newVal;               }

/// Channel Decimal
char P3RawFile::GetChanDecimal(int iChan)
{  return m_RawHeader.acDecimal[iChan];                 }
void P3RawFile::SetChanDecimal(int iChan, char newVal)
{  m_RawHeader.acDecimal[iChan] = newVal;               }

/// Channel Divisor
USHORT P3RawFile::GetChanDivisor(int iChan)
{  return m_RawHeader.sDivisor[iChan];                 }
void P3RawFile::SetChanDivisor(int iChan, USHORT newVal)
{  m_RawHeader.sDivisor[iChan] = newVal;               }

/// Channel High Cal
float P3RawFile::GetChanHighCal(int iChan)
{  return m_RawHeader.afHighCal[iChan];                 }
void P3RawFile::SetChanHighCal(int iChan, float newVal)
{  m_RawHeader.afHighCal[iChan] = newVal;               }

/// Channel Low Cal
float P3RawFile::GetChanLowCal(int iChan)
{  return m_RawHeader.afLowCal[iChan];                 }
void P3RawFile::SetChanLowCal(int iChan, float newVal)
{  m_RawHeader.afLowCal[iChan] = newVal;               }

/// Channel AD High
short P3RawFile::GetChanADHigh(int iChan)
{  return m_RawHeader.Group[0][iChan].AD_High;                 }
void P3RawFile::SetChanADHigh(int iChan, short newVal)
{  m_RawHeader.Group[0][iChan].AD_High = newVal;               }

/// Channel AD Low
short P3RawFile::GetChanADLow(int iChan)
{  return m_RawHeader.Group[0][iChan].AD_Low;                 }
void P3RawFile::SetChanADLow(int iChan, short newVal)
{  m_RawHeader.Group[0][iChan].AD_Low = newVal;               }

/// Channel Scale
float P3RawFile::GetChanScale(int iChan)
{  return m_RawHeader.Group[0][iChan].Scale;                 }
void P3RawFile::SetChanScale(int iChan, float newVal)
{  m_RawHeader.Group[0][iChan].Scale = newVal;               }

/// Get Channel ID.
void P3RawFile::GetChanID(int iChan, char* pVal, int iCount)
{
   strncpy(pVal, m_RawHeader.Group[0][iChan].ChanID, iCount);
}

/// Put User Name.
void P3RawFile::SetChanID(int iChan, LPCTSTR newVal)
{
   strncpy(m_RawHeader.Group[0][iChan].ChanID, newVal, 9);
}

/// Copy Header info from 1 Raw File to current Raw File.
HRESULT P3RawFile::CopyHeaderInfo(P3RawFile *pRawFile)
{
   char szString[100];
   ULONG iYear, iMonth, iDay;
   WORD sHours, sMinutes, sSeconds;

   // Date
   CHECK_RETURN( pRawFile->GetFileDate(&iYear, &iMonth, &iDay) );
   CHECK_RETURN( SetFileDate(iYear, iMonth, iDay) );
   
   // Time
   CHECK_RETURN( pRawFile->GetFileTime(&sHours, &sMinutes, &sSeconds) );
   CHECK_RETURN( SetFileTime(sHours, sMinutes, sSeconds) );

   // UserName
   pRawFile->GetUserName(szString, 100);
   SetUserName(szString);
   
   // Sample Rate
   SetSampleRate(pRawFile->GetSampleRate() );
   
   // CP Serial
   SetCPSerial(pRawFile->GetCPSerial() );
   
   // AD Serial
   SetADSerial(pRawFile->GetADSerial() );
   
   // Channel Count
   SetChannelCount(pRawFile->GetChannelCount() );

   // Copy channel properties
   for (int iChan=0; iChan < m_RawHeader.sNumChannels; iChan++)
   {
      // Channel Type
      SetChanType(iChan, pRawFile->GetChanType(iChan) );

      // Channel Decimal
      SetChanDecimal(iChan, pRawFile->GetChanDecimal(iChan) );

      // Channel Divisor
      SetChanDivisor(iChan, pRawFile->GetChanDivisor(iChan) );

      // Channel High Cal
      SetChanHighCal(iChan, pRawFile->GetChanHighCal(iChan) );

      // Channel Low Cal
      SetChanLowCal(iChan, pRawFile->GetChanLowCal(iChan) );

      // Channel AD High
      SetChanADHigh(iChan, pRawFile->GetChanADHigh(iChan) );

      // Channel AD Low
      SetChanADLow(iChan, pRawFile->GetChanADLow(iChan) );

      // Channel Scale
      SetChanScale(iChan, pRawFile->GetChanScale(iChan) );
      
      // Channel ID
      pRawFile->GetChanID(iChan, szString, 100);
      SetChanID(iChan, szString);
   }

   return S_OK;
}

int P3RawFile::GetCurrentDivisorCount(int iChan)
{
   return m_sDivisorCount[iChan];
}

void P3RawFile::SetCurrentDivisorCount(int iChan, int iDivisor)
{
   m_sDivisorCount[iChan] = iDivisor;
}

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
// Helper Functions

union DPswap_val
{
   float f1;
   unsigned char  b1[4];
   unsigned long  l1;
};

/// Read a LONG value from the file
LONG P3RawFile::ReadLong()
{
   if (m_hFile == INVALID_HANDLE_VALUE)
      throw RAWERR_FILE_NOT_OPEN;

   DWORD dwBytesRead;
   LONG x;
   ReadFile(m_hFile, &x, 4, &dwBytesRead, NULL);

   if (!m_RawHeader.bExtendedFile)
      return SwapLong(x);
   else
      return x;
}

/// Read a string value from the file
void P3RawFile::ReadString(char *szVal, int iLength)
{
   if (m_hFile == INVALID_HANDLE_VALUE)
      throw RAWERR_FILE_NOT_OPEN;
/*
   BOOL bEndLine = FALSE;
   memset(szVal, 0, iLength);
   for (int x=0; x<iLength; x++)
   {
      char ch;
      m_pFile->Read(&ch, 1);
      if (ch == '\0')
         bEndLine = TRUE;
      if (!bEndLine)
         szRet.Append(ch);
   }*/

   BOOL bFree = FALSE;
   char* pBuffer = szVal;
   if (szVal == NULL)
   {
      bFree = TRUE;
      pBuffer = (char*)malloc(iLength+1);
   }

   DWORD dwBytesRead;
   ReadFile(m_hFile, pBuffer, iLength, &dwBytesRead, NULL);

   if (bFree)
      free(pBuffer);
}

/// Read a 64bit integer value from the file
ULONGLONG P3RawFile::ReadInt64()
{
   if (m_hFile == INVALID_HANDLE_VALUE)
      throw RAWERR_FILE_NOT_OPEN;

   DWORD dwBytesRead;
   UINT64 x;
   ReadFile(m_hFile, &x, 8, &dwBytesRead, NULL);

   return x;
}

/// Read a float value from the file
float P3RawFile::ReadFloat()
{
   if (m_hFile == INVALID_HANDLE_VALUE)
      throw RAWERR_FILE_NOT_OPEN;

   union DPswap_val temp;
   long  fv;
   
   DWORD dwBytesRead;
   ReadFile(m_hFile, &temp.l1, 4, &dwBytesRead, NULL);
    
   if (!m_RawHeader.bExtendedFile)
   {
      fv = SwapLong(temp.l1);
      temp.l1 = fv;
      return temp.f1;
   }
   return temp.f1;
}

/// Read a SHORT value from the file
USHORT P3RawFile::ReadShort()
{
   if (m_hFile == INVALID_HANDLE_VALUE)
      throw RAWERR_FILE_NOT_OPEN;

   DWORD dwBytesRead;
   USHORT tv;
   ReadFile(m_hFile, &tv, 2, &dwBytesRead, NULL);
    
   if (!m_RawHeader.bExtendedFile)
   {
      USHORT temp;
      temp = ((tv & 0xff00) >> 8) & 0x00ff;
      temp |= (tv & 0x00ff) << 8;
      return temp;
   }
   else
      return tv;
}

/// Read a single char value from the file
char P3RawFile::ReadChar()
{
   if (m_hFile == INVALID_HANDLE_VALUE)
      throw RAWERR_FILE_NOT_OPEN;

   DWORD dwBytesRead;
   char ch;
   ReadFile(m_hFile, &ch, 1, &dwBytesRead, NULL);

   return ch;
}

/// Swap a 4 byte value (abcd -> dcba)
LONG P3RawFile::SwapLong(long value)
{
   union DPswap_val temp;
   unsigned char  temp2;

   temp.l1=value;
   temp2=temp.b1[0];
   temp.b1[0]=temp.b1[3];
   temp.b1[3]=temp2;
   temp2=temp.b1[1];
   temp.b1[1]=temp.b1[2];
   temp.b1[2]=temp2;
   return(temp.l1);
}


/// Read a LONG value from the given buffer
/// \param pBuffer Memory buffer to read from
LONG P3RawFile::BufferReadLong(char** pBuffer)
{
   LONG x;
   memcpy(&x, *pBuffer, 4);
   *pBuffer += 4;

   if (!m_RawHeader.bExtendedFile)
      return SwapLong(x);
   else
      return x;
}

/// Read a 64 bit integer value from the given buffer
/// \param pBuffer Memory buffer to read from
ULONGLONG P3RawFile::BufferReadInt64(char** pBuffer)
{
   ULONGLONG x;
   memcpy(&x, *pBuffer, 8);
   *pBuffer += 8;

   return x;
}

/// Read a single char value from the given buffer
/// \param pBuffer Memory buffer to read from
char P3RawFile::BufferReadChar(char** pBuffer)
{
   char ch;
   memcpy(&ch, *pBuffer, 1);
   *pBuffer += 1;
   return ch;
}

/// Read a SHORT value from the given buffer
/// \param pBuffer Memory buffer to read from
USHORT P3RawFile::BufferReadShort(char** pBuffer)
{
   USHORT tv;
   memcpy(&tv, *pBuffer, 2);
   *pBuffer += 2;
    
   if (!m_RawHeader.bExtendedFile)
   {
      USHORT temp;
      temp = ((tv & 0xff00) >> 8) & 0x00ff;
      temp |= (tv & 0x00ff) << 8;
      return temp;
   }
   else
      return tv;
}

/// Read a float value from the file
float P3RawFile::BufferReadFloat(char** pBuffer)
{
   union DPswap_val temp;
   long  fv;
   
   memcpy(&temp.l1, *pBuffer, 4);
   *pBuffer += 4;
    
   if (!m_RawHeader.bExtendedFile)
   {
      fv = SwapLong(temp.l1);
      temp.l1 = fv;
      return temp.f1;
   }
   return temp.f1;
}