#pragma once

#define RETURN_ERR(x)         return MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, x);
#define CHECK_RETURN(x)       {HRESULT hr=x; if (!SUCCEEDED(hr)) return hr;}
#define IS_RAWERR(hr, err)    (hr == MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, err) )
#define MAKE_WINERR           MAKE_HRESULT(SEVERITY_ERROR, FACILITY_WIN32, GetLastError())


const int      FILLER_LENGTH           =  124; // Filler space
const UINT64   NANO_FACTOR             =  1000000000;
const int      DELTA_TICK_RES          =  100000;
const int      BLOCK_TIME_MARKER       =  1;
const int      OLD_JMP_OFFSET          =  12;  // used for 32bit offset
const int      EXT_JMP_OFFSET          =  56;  // used for 64bit offset
const int      MAX_BLOCK_SIZE          =  0x20000;

const float   FloatFactor[]={(float)1.0, (float)0.1, (float)0.01, (float)0.001, (float)0.0001, (float)0.00001};