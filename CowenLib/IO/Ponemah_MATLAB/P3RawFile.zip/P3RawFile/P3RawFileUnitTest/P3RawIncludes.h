


const int      RAWFILE_ERROR_START     =  0x2000;	// Start index for error codes


enum RAW_FILE_ERROR_CODES{
   RAWERR_NO_JUMP = (RAWFILE_ERROR_START + 1),		///< Jump File not found
   RAWERR_FILE_ALREADY_OPEN,                       ///< Raw File is already open
   RAWERR_CANNOT_CREATE_FILE,                      ///< Unable to create the Raw File
   RAWERR_FILE_NOT_OPEN,                           ///< Raw File is not open, cannot perform request
   RAWERR_RAWHEADER_NOT_VALID,                     ///< The Raw File does not contain a valid Raw Header
   RAWERR_RAWHEADER_ALREADY_WRITTEN,               ///< The Raw Header has alreawdy been written, cannot modify
   RAWERR_CANNOT_OPEN_JUMP,                        ///< Cannot open the jump file
   RAWERR_NO_MORE_BLOCKS,                          ///< No more blocks, end of file reached
   RAWERR_CANCELED,                                ///< Action canceled
   RAWERR_JUMPFILE_ERROR,                          ///< Error encountered in the jump file
   RAWERR_NEED_CALC_DATA_TIMES,                    ///< CalcDataTimes has not been called, expected to have been called
   RAWERR_END_OF_BLOCK,                            ///< End of data in block
   RAWERR_APPEND_NOT_SUPPORTED,                    ///< Currently, Appended raw file not supported
   RAWERR_UNEXPECTED_END_OF_FILE,                  ///< Reached EOF when not expected, middle of an operation
   RAWERR_UNDETERMINED,                            ///< Unknown Error
};