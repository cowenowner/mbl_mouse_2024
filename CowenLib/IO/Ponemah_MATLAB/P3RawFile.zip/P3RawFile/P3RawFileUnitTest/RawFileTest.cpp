#include "stdafx.h"
#include <float.h>
#include "RawFileTest.h"
#include "..\P3RawFile.h"

CPPUNIT_TEST_SUITE_REGISTRATION( RawFileTest );


extern char* FULLDEMO_RAW         =  "FULLDEMO.RAW";
extern char* FULLDEMO_NEW_JUMP    =  "FULLDEMO.JMP";
extern char* FULLDEMO_TEST_JUMP   =  "FULLDEMO.TEST.JMP";
extern char* FULLDEMO_ORIG_JUMP   =  "FULLDEMO.ORIG.JMP";

extern char* EXTENDED2_RAW        =  "EXTENDED2.RAW";
extern char* EXTENDED2_NOJUMP     =  "EXTENDED2.NOJUMP.RAW";
extern char* EXTENDED2_TEMP       =  "EXTENDED2_TEMP.RAW";

extern char* UNITTEST_RAW         =  "UNITTEST.RAW";

extern char* NODATA_RAW           =  "NODATA.RAW";

extern char* TWELVELEAD_RAW       =  "12LEAD.RAW";

extern char* LARGE_1_ECG_RAW      =  "LARGEONEECG.RAW";

extern char* HOUR_LIGHT_RAW       =  "HOURLIGHT.RAW";


#define CPPUNIT_ASSERT_SUCCEEDED(x)          CPPUNIT_ASSERT(SUCCEEDED(x))
#define CPPUNIT_ASSERT_RAWFILE_ERR(err, x)   CPPUNIT_ASSERT_EQUAL( \
                                                MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, err), x)

class CRawFileOpener : public P3FileOpener
{
public:

   HRESULT OpenFile(HANDLE* hFile, LPCTSTR szFileName, DWORD dwDesiredAccess, DWORD dwShareMode, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes) 
   {
      CString szTempName = (m_szOpenFile == "") ? szFileName : m_szOpenFile;
      *hFile = CreateFile(szTempName, dwDesiredAccess, dwShareMode, NULL, dwCreationDisposition, dwFlagsAndAttributes, NULL);
      return S_OK;
   };
   
   HRESULT DeleteFile(LPCTSTR szFileName) 
   {
      return S_OK;
   };
   
   void SetFilename(LPCTSTR szOpenFile)
      {m_szOpenFile = szOpenFile;};

protected:
   CString m_szOpenFile;
};


void RawFileTest::setUp ()
{
   /////////////////////////////////////////////////
   // Get Testing Data Directory
   char szTemp[MAX_PATH];
   GetModuleFileName(NULL, szTemp, sizeof(szTemp));
   m_szDataDir = szTemp;
   m_szDataDir = m_szDataDir.Left(m_szDataDir.ReverseFind('\\'));
   m_szDataDir = m_szDataDir.Left(m_szDataDir.ReverseFind('\\'));
   m_szDataDir += "\\TestData\\";
   
   DeleteUnwantedFiles();
}

void RawFileTest::tearDown ()
{
   DeleteUnwantedFiles();
}

void RawFileTest::DeleteUnwantedFiles()
{
   // Delete any files that may be created by these tests (catch exception if file is not there)
   try { CFile::Remove(m_szDataDir + FULLDEMO_NEW_JUMP); } catch (CFileException*){}
   try { CFile::Remove(m_szDataDir + EXTENDED2_TEMP); } catch (CFileException*){}
   try { CFile::Remove(m_szDataDir + UNITTEST_RAW); } catch (CFileException*){}
}

void RawFileTest::Open_Close()
{
   P3RawFile RawFile;

   ///////////////////////////////////////////////////////////////
   // Ensure not open, then open, ensure open, then close, and ensure not open
   CPPUNIT_ASSERT( !RawFile.IsOpen() );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );
   CPPUNIT_ASSERT( RawFile.IsOpen() );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
   CPPUNIT_ASSERT( !RawFile.IsOpen() );

   ///////////////////////////////////////////////////////////////
   // Ensure opening a non-existant file returns File Not Found (2)
   HRESULT hr = RawFile.OpenFile(m_szDataDir + "non_existant_file");
   CPPUNIT_ASSERT_EQUAL( MAKE_HRESULT(SEVERITY_ERROR, FACILITY_WIN32, 2), hr);

   ///////////////////////////////////////////////////////////////
   // Check known sample rate
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );
   CPPUNIT_ASSERT_EQUAL( (float)250, RawFile.GetSampleRate() );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
   
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + EXTENDED2_RAW) );
   CPPUNIT_ASSERT_EQUAL( (float)1000, RawFile.GetSampleRate() );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );

   ///////////////////////////////////////////////////////////////
   // Test opening files with IFileOpener
   // - To test, tell RawFile to open FullDemo, but have Opener open Extended2, 
   //   and check differing sample rate
   CRawFileOpener *pOpener = new CRawFileOpener();
   pOpener->SetFilename(m_szDataDir + EXTENDED2_RAW);

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.SetFileOpener(pOpener) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );
   CPPUNIT_ASSERT_EQUAL( (float)1000, RawFile.GetSampleRate() );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );

   delete pOpener;
}


void RawFileTest::TestFullDemoTime()
{
   P3RawFile RawFile;
   
   WORD sHours, sMinutes, sSeconds, sTicks;
   ULONG iYear, iMonth, iDay;

   // Open FULLDEMO and Setup time
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );

   ///////////////////////////////////////////////////////////////
   // FILE DATE & TIME
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetFileTime(&sHours, &sMinutes, &sSeconds) );
   CPPUNIT_ASSERT_EQUAL( (WORD)10, sHours );
   CPPUNIT_ASSERT_EQUAL( (WORD)51, sMinutes );
   CPPUNIT_ASSERT_EQUAL( (WORD)33, sSeconds );

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetFileDate(&iYear, &iMonth, &iDay) );
   CPPUNIT_ASSERT_EQUAL( (ULONG)1995, iYear );
   CPPUNIT_ASSERT_EQUAL( (ULONG)4, iMonth );
   CPPUNIT_ASSERT_EQUAL( (ULONG)19, iDay );

   ///////////////////////////////////////////////////////////////
   // ELAPSED TIME
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetCurrentElapsedTime(&sHours, &sMinutes, &sSeconds, &sTicks) );
   CPPUNIT_ASSERT_EQUAL( (WORD)0, sHours );
   CPPUNIT_ASSERT_EQUAL( (WORD)6, sMinutes );
   CPPUNIT_ASSERT_EQUAL( (WORD)9, sSeconds );
   CPPUNIT_ASSERT_EQUAL( (WORD)0, sTicks );

   // Test Elapsed Time in Nanoseconds (known start time of FULLDEMO)
   CPPUNIT_ASSERT( (INT64)369000000000 == RawFile.GetCurrentNanoSeconds() );

   ///////////////////////////////////////////////////////////////
   // REAL TIME
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetCurrentRealTime(&sHours, &sMinutes, &sSeconds, &sTicks) );
   CPPUNIT_ASSERT_EQUAL( (WORD)10, sHours );
   CPPUNIT_ASSERT_EQUAL( (WORD)57, sMinutes );
   CPPUNIT_ASSERT_EQUAL( (WORD)42, sSeconds );
   CPPUNIT_ASSERT_EQUAL( (WORD)0, sTicks );
   
   // CURRENT DATE
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetCurrentRealDate(&iYear, &iMonth, &iDay) );
   CPPUNIT_ASSERT_EQUAL( (ULONG)1995, iYear );
   CPPUNIT_ASSERT_EQUAL( (ULONG)4, iMonth );
   CPPUNIT_ASSERT_EQUAL( (ULONG)19, iDay );

   // Close File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
}

/////////////////////////////////////////////////
// Check Data points in FullDemo
void RawFileTest::TestFullDemoData()
{
   P3RawFile RawFile;
   
   // Open FULLDEMO and Setup time
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );
   
   float Signals[8];

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetNextSampleScaled(Signals, 8) );

   ////////////////////////////////////////////////
   // Check Data
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 121.311,    Signals[0], 0.001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 9.63915,    Signals[1], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0138249,  Signals[2], 0.0000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( -0.682266,  Signals[3], 0.0000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 11.9287,    Signals[4], 0.0001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 7.77778,    Signals[5], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.388242,   Signals[6], 0.000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( -1.30526,   Signals[7], 0.00001);

   ////////////////////////////////////////////////
   // Verify time moved
   CPPUNIT_ASSERT( (INT64)369004000000 == RawFile.GetCurrentNanoSeconds() );
   
   ////////////////////////////////////////////////
   // Cycle to next data block
   while (RawFile.GetCurrentNanoSeconds() <= 377128000000)
   {
      if (S_OK != RawFile.GetNextSampleScaled(Signals, 8))
         CPPUNIT_ASSERT(FALSE);
   }

   ////////////////////////////////////////////////
   // Check Data
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 122.234,    Signals[0], 0.001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 112.160,    Signals[1], 0.001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0138249,  Signals[2], 0.0000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( -0.743842,  Signals[3], 0.000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 24.2230,    Signals[4], 0.0001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 6.33333,    Signals[5], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 13.2696,    Signals[6], 0.0001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.20000,    Signals[7], 0.00001);

   ////////////////////////////////////////////////
   // Verify time moved
   CPPUNIT_ASSERT( (INT64)377132000000 == RawFile.GetCurrentNanoSeconds() );

   ////////////////////////////////////////////////
   // Cycle to End of Data
   while (RawFile.GetCurrentNanoSeconds() < 872932000000)
   {
      if (S_OK != RawFile.GetNextSampleScaled(Signals, 8))
         CPPUNIT_ASSERT(FALSE);
   }
   // Read last sample
   if (S_OK != RawFile.GetNextSampleScaled(Signals, 8))
      CPPUNIT_ASSERT(FALSE);

   // Ensure next sample returns error - end of data
   CPPUNIT_ASSERT_EQUAL( MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, RAWERR_NO_MORE_BLOCKS), 
                         RawFile.GetNextSampleScaled(Signals, 8) );

   // Close File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
}

/////////////////////////////////////////////////
// Create a Jump file in FullDemo
void RawFileTest::CreateJump()
{
   P3RawFile RawFile;
   
   ////////////////////////////////////////////////
   // Open FULLDEMO
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );
   CPPUNIT_ASSERT( !RawFile.DoesJumpExist() );

   // Create Jump File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateJumpFile(TRUE) );
   CPPUNIT_ASSERT( RawFile.DoesJumpExist() );

   // Ensure jump file is correct - test against known jump file
   CPPUNIT_ASSERT (CompareFiles(m_szDataDir + FULLDEMO_NEW_JUMP, m_szDataDir + FULLDEMO_TEST_JUMP));
   
   // Close File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );

   ////////////////////////////////////////////////
   // Open EXTENDED2
   CopyFile(m_szDataDir + EXTENDED2_NOJUMP, m_szDataDir + EXTENDED2_TEMP, FALSE);

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + EXTENDED2_TEMP) );
   CPPUNIT_ASSERT( !RawFile.DoesJumpExist() );

   // Create EXTENDED2 jump table
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateJumpFile(TRUE) );
   CPPUNIT_ASSERT( RawFile.DoesJumpExist() );

   // Ensure jump file is correct - test against known jump file
   CPPUNIT_ASSERT (CompareFiles(m_szDataDir + EXTENDED2_TEMP, m_szDataDir + EXTENDED2_RAW));
   
   // Close File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );

}


/////////////////////////////////////////////////
// Jump to a time in FullDemo
void RawFileTest::FullDemoJumpToTime()
{
   P3RawFile RawFile;
   float Signals[8];

   // Open FULLDEMO
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );

   // Test that Jump fails (No jump file) - then create it
   CPPUNIT_ASSERT_RAWFILE_ERR( RAWERR_NO_JUMP, RawFile.JumpToTime(420000000000) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateJumpFile(TRUE) );

   ////////////////////////////////////////////////
   // Jump to known time (7:00)
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.JumpToTime(420000000000) );
   
   // Verify time moved
   CPPUNIT_ASSERT( (INT64)420000000000 == RawFile.GetCurrentNanoSeconds() );

   // Get Next Sample
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetNextSampleScaled(Signals, 8) );

   // Test Data
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 132.787,    Signals[0], 0.001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.39941,    Signals[1], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0115207,  Signals[2], 0.0000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( -0.549261,  Signals[3], 0.000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 20.7952,    Signals[4], 0.0001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.49206,    Signals[5], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.83250,    Signals[6], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.49053,    Signals[7], 0.00001);

   ////////////////////////////////////////////////
   // Jump to time before RAW file starts
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.JumpToTime(40000000000) );
   
   // Verify time moved
   CPPUNIT_ASSERT( (INT64)369000000000 == RawFile.GetCurrentNanoSeconds() );
   
   // Get Next Sample
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetNextSampleScaled(Signals, 8) );

   // Test Data
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 121.311,    Signals[0], 0.001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 9.63915,    Signals[1], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0138249,  Signals[2], 0.0000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( -0.682266,  Signals[3], 0.0000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 11.9287,    Signals[4], 0.0001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 7.77778,    Signals[5], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.388242,   Signals[6], 0.000001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( -1.30526,   Signals[7], 0.00001);

   ////////////////////////////////////////////////
   // Jump to time after RAW file ends
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.JumpToTime(900000000000) );
   
   // Verify time moved
   CPPUNIT_ASSERT( (INT64)872932000000 == RawFile.GetCurrentNanoSeconds() );
   
   // Get Next Sample
   CPPUNIT_ASSERT_RAWFILE_ERR( RAWERR_NO_MORE_BLOCKS, RawFile.GetNextSampleScaled(Signals, 8) );

   // Close File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
}

/////////////////////////////////////////////////
// Jump to a time in Extended2
void RawFileTest::Extended2JumpToTime()
{
   P3RawFile RawFile;
   float Signals[2];

   ////////////////////////////////////////////////
   // Open EXTENDED2
   CopyFile(m_szDataDir + EXTENDED2_NOJUMP, m_szDataDir + EXTENDED2_TEMP, FALSE);

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + EXTENDED2_TEMP) );

   // Test that Jump fails (No jump file) - then create it
   CPPUNIT_ASSERT_RAWFILE_ERR( RAWERR_NO_JUMP, RawFile.JumpToTime(15000000000) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateJumpFile(TRUE) );

   // Jump to known time (1:20)
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.JumpToTime(15000000000) );
   
   // Verify time moved
   CPPUNIT_ASSERT( (INT64)15000000000 == RawFile.GetCurrentNanoSeconds() );

   // Get Next Sample
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetNextSampleScaled(Signals, 2) );

   // Test Data
   CPPUNIT_ASSERT_DOUBLES_EQUAL( -3.03909,   Signals[0], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.73851,    Signals[1], 0.00001);
   
   // Get Next Sample
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.GetNextSampleScaled(Signals, 2) );

   // Test Data
   CPPUNIT_ASSERT_DOUBLES_EQUAL( -3.04452,   Signals[0], 0.00001);
   CPPUNIT_ASSERT_DOUBLES_EQUAL( FLT_MIN,    Signals[1], 0.00001);
   
   // Close File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
}

/////////////////////////////////////////////////
// Test writing an empty RAW header
void RawFileTest::WriteRawHeader()
{
   P3RawFile RawFile, NoDataFile;
   
   // Open NoData file - to get date and time (will return error when reading block header - no data)
   CPPUNIT_ASSERT_RAWFILE_ERR( RAWERR_NO_MORE_BLOCKS, NoDataFile.OpenFile(m_szDataDir + NODATA_RAW) );

   // Create new raw file
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateFile(m_szDataDir + UNITTEST_RAW) );

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CopyHeaderInfo(&NoDataFile) );

   // Write Data - Not saving so only raw header is written
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.PutNextSampleUnscaled(FALSE, NULL, 0) );

   // Close Files
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
   CPPUNIT_ASSERT_SUCCEEDED( NoDataFile.CloseFile() );

   // Check against known no-data file
   CPPUNIT_ASSERT (CompareFiles(m_szDataDir + UNITTEST_RAW, m_szDataDir + NODATA_RAW));
}

/////////////////////////////////////////////////
// Test writing a RAW file (read in samples, write them out, then compare files)
void RawFileTest::TestAcquisition()
{
   P3RawFile RawFile, Extended2Raw;

   HRESULT  hr;
   INT64    i64Nano;
   INT64    i64PreviousNano;
   INT64    i64TimeStep;
   BOOL     bDone;
   short    Samples[2];
   float    Signals[2];

   ///////////////////////////
   // Unscaled - Use only PutNextSample

   // Open extended2 file - to get date and time (must be latest version so files will be identical)
   CPPUNIT_ASSERT_SUCCEEDED( Extended2Raw.OpenFile(m_szDataDir + EXTENDED2_RAW) );
   
   // Create new raw file
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateFile(m_szDataDir + UNITTEST_RAW) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CopyHeaderInfo(&Extended2Raw) );

   // Simulate Acquisition
   i64Nano = 0;
   i64PreviousNano = 0;
   i64TimeStep = Extended2Raw.GetTimeSlice();

   bDone = FALSE;

   while (!bDone)
   {
      hr = Extended2Raw.GetNextSampleUnscaled(Samples, 2);
      bDone = !SUCCEEDED(hr);
      i64Nano = Extended2Raw.GetCurrentNanoSeconds();
      if (!bDone)
      {
         CPPUNIT_ASSERT_SUCCEEDED( RawFile.PutNextSampleUnscaled(TRUE, Samples, 2, NULL) );

         while (i64PreviousNano < (i64Nano - i64TimeStep) )
         {
            CPPUNIT_ASSERT_SUCCEEDED( RawFile.PutNextSampleUnscaled(FALSE, NULL, 0, NULL) );
            i64PreviousNano += i64TimeStep;
         }

         i64PreviousNano = i64Nano;
      }
   }
   CPPUNIT_ASSERT_RAWFILE_ERR( RAWERR_NO_MORE_BLOCKS, hr );

   // Close Files
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
   CPPUNIT_ASSERT_SUCCEEDED( Extended2Raw.CloseFile() );

   // Check against known Extended2 file
   CPPUNIT_ASSERT (CompareFiles(m_szDataDir + UNITTEST_RAW, m_szDataDir + EXTENDED2_RAW) );

   ///////////////////////////
   // Scaled - Use BreakToTime

   // Open extended2 file - to get date and time (must be latest version so files will be identical)
   CPPUNIT_ASSERT_SUCCEEDED( Extended2Raw.OpenFile(m_szDataDir + EXTENDED2_RAW) );

   // Create new raw file
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateFile(m_szDataDir + UNITTEST_RAW) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CopyHeaderInfo(&Extended2Raw) );

   // Simulate Acquisition
   i64Nano = 0;
   i64PreviousNano = 0;
   i64TimeStep = Extended2Raw.GetTimeSlice();

   bDone = FALSE;

   while (!bDone)
   {
      hr =  Extended2Raw.GetNextSampleScaled(Signals, 2);
      bDone = !SUCCEEDED(hr);
      i64Nano = Extended2Raw.GetCurrentNanoSeconds();

      if (!bDone)
      {
         CPPUNIT_ASSERT_SUCCEEDED( RawFile.PutNextSampleScaled(TRUE, Signals, 2, NULL) );

         if (i64PreviousNano < (i64Nano - i64TimeStep) )
         {
            CPPUNIT_ASSERT_SUCCEEDED( RawFile.BreakToTime(i64Nano) );
         }

         i64PreviousNano = i64Nano;
      }
   }
   CPPUNIT_ASSERT_RAWFILE_ERR( RAWERR_NO_MORE_BLOCKS, hr );
   
   // Close Files
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
   CPPUNIT_ASSERT_SUCCEEDED( Extended2Raw.CloseFile() );

   // Check against known Extended2 file
   CPPUNIT_ASSERT (CompareFiles(m_szDataDir + UNITTEST_RAW, m_szDataDir + EXTENDED2_RAW) );
}


/////////////////////////////////////////////////
// Viewer, Aquire a file, then replay it while it is still open
void RawFileTest::TestViewer()
{
   P3RawFile RawFile, Extended2Raw, ViewerRaw;

   LONG     iSample;
   short    SamplesIn[2];
   short    SamplesOut[2];

   // Open extended2 file - to get date and time (must be latest version so files will be identical)
   CPPUNIT_ASSERT_SUCCEEDED( Extended2Raw.OpenFile(m_szDataDir + EXTENDED2_RAW) );

   // Create new raw file for acq
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateFile(m_szDataDir + UNITTEST_RAW) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CopyHeaderInfo(&Extended2Raw) );

   SamplesIn[0] = 20;
   SamplesIn[1] = 20;

   // Add data to the acq file
   for (iSample=0; iSample < 3000; iSample++)
      CPPUNIT_ASSERT_SUCCEEDED( RawFile.PutNextSampleUnscaled(TRUE, SamplesIn, 2) );

   // Open newly created RAW file for viewer mode
   CPPUNIT_ASSERT_SUCCEEDED( ViewerRaw.OpenFile(m_szDataDir + UNITTEST_RAW) );

   // Read from viewer file until end
   for (iSample=0; iSample < 3000; iSample++)
   {
      CPPUNIT_ASSERT_SUCCEEDED( ViewerRaw.GetNextSampleUnscaled(SamplesOut, 2) );
      CPPUNIT_ASSERT_EQUAL( (short)20, SamplesOut[0] );
      if ( (iSample % 2) == 0)
         CPPUNIT_ASSERT_EQUAL( (short)20, SamplesOut[1] );
      else
         CPPUNIT_ASSERT_EQUAL( (short)SHRT_MIN, SamplesOut[1] );
   }

   // Ensure we are at the end of the raw file
   CPPUNIT_ASSERT_RAWFILE_ERR( RAWERR_NO_MORE_BLOCKS, ViewerRaw.GetNextSampleUnscaled(SamplesOut, 2) );
  
   // Add more data to the acq file
   for (iSample=0; iSample < 3000; iSample++)
      CPPUNIT_ASSERT_SUCCEEDED( RawFile.PutNextSampleUnscaled(TRUE, SamplesIn, 2) );

   // Read from viewer file until end
   for (iSample=0; iSample < 3000; iSample++)
   {
      CPPUNIT_ASSERT_SUCCEEDED( ViewerRaw.GetNextSampleUnscaled(SamplesOut, 2) );
      CPPUNIT_ASSERT_EQUAL( (short)20, SamplesOut[0] );
      if ( (iSample % 2) == 0)
         CPPUNIT_ASSERT_EQUAL( (short)20, SamplesOut[1] );
      else
         CPPUNIT_ASSERT_EQUAL( (short)SHRT_MIN, SamplesOut[1] );
   }

   // Ensure we are at the end of the raw file
   CPPUNIT_ASSERT_RAWFILE_ERR( RAWERR_NO_MORE_BLOCKS, ViewerRaw.GetNextSampleUnscaled(SamplesOut, 2) );

   // Try jumping -  should ignore lack of table and use jump file
   CPPUNIT_ASSERT_SUCCEEDED( ViewerRaw.JumpToTime(1000000000) );

   // Verify time moved
   CPPUNIT_ASSERT( (INT64)1000000000 == ViewerRaw.GetCurrentNanoSeconds() );

   // Close Files
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
   CPPUNIT_ASSERT_SUCCEEDED( Extended2Raw.CloseFile() );
   CPPUNIT_ASSERT_SUCCEEDED( ViewerRaw.CloseFile() );
}

/////////////////////////////////////////////////
// CalcDataTimes - cycle through jump file and calculate data times
void RawFileTest::TestCalcDataTimes()
{
   P3RawFile RawFile;

   INT64 *pStartTimes = NULL;
   INT64 *pEndTimes = NULL;
   int iCount = 0;

   ///////////////////////////////////////////////////////////////   
   // Open EXTENDED_2
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + EXTENDED2_RAW) );
   CPPUNIT_ASSERT( E_FAIL == RawFile.CalculateDataTimes(NULL, NULL, &iCount) );
   CPPUNIT_ASSERT( 4 == iCount);

   pStartTimes = (INT64*)realloc(pStartTimes, sizeof(INT64)*iCount);
   pEndTimes = (INT64*)realloc(pEndTimes, sizeof(INT64)*iCount);
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CalculateDataTimes(pStartTimes, pEndTimes, &iCount) );

   // Verify Times
   CPPUNIT_ASSERT( (INT64)          0 == pStartTimes[0] );
   CPPUNIT_ASSERT( (INT64) 6999000000 == pEndTimes[0] );
   CPPUNIT_ASSERT( (INT64)11000000000 == pStartTimes[1] );
   CPPUNIT_ASSERT( (INT64)15999000000 == pEndTimes[1] );
   CPPUNIT_ASSERT( (INT64)20000000000 == pStartTimes[2] );
   CPPUNIT_ASSERT( (INT64)25999000000 == pEndTimes[2] );
   CPPUNIT_ASSERT( (INT64)28000000000 == pStartTimes[3] );
   CPPUNIT_ASSERT( (INT64)33999000000 == pEndTimes[3] );

   // Close File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );

   ///////////////////////////////////////////////////////////////   
   // Open and Test FullDemo - tests CalcBlockEndTime, since end time not in old style block headers
   iCount = 0;
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateJumpFile(TRUE) );
   CPPUNIT_ASSERT( E_FAIL == RawFile.CalculateDataTimes(NULL, NULL, &iCount) );
   CPPUNIT_ASSERT( 1 == iCount);
   
   pStartTimes = (INT64*)realloc(pStartTimes, sizeof(INT64)*iCount);
   pEndTimes = (INT64*)realloc(pEndTimes, sizeof(INT64)*iCount);
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CalculateDataTimes(pStartTimes, pEndTimes, &iCount) );

   // Verify Times
   CPPUNIT_ASSERT( (INT64) 369000000000 == pStartTimes[0] );
   CPPUNIT_ASSERT( (INT64) 872932000000 == pEndTimes[0] );
   
   // Close File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );

   ///////////////////////////////////////////////////////////////   
   // Open and Test TwelveLead - tests DT3000 error correction, extra samples in blocks
   iCount = 0;
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + TWELVELEAD_RAW) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateJumpFile(TRUE) );
   CPPUNIT_ASSERT( E_FAIL == RawFile.CalculateDataTimes(NULL, NULL, &iCount) );
   CPPUNIT_ASSERT( 1 == iCount);
   
   pStartTimes = (INT64*)realloc(pStartTimes, sizeof(INT64)*iCount);
   pEndTimes = (INT64*)realloc(pEndTimes, sizeof(INT64)*iCount);
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CalculateDataTimes(pStartTimes, pEndTimes, &iCount) );

   // Verify Times
   CPPUNIT_ASSERT( (INT64) 3601017000000 == pStartTimes[0] );
   CPPUNIT_ASSERT( (INT64) 3906986000000 == pEndTimes[0] );
   
   // Close File
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
}


void RawFileTest::TestJumpZero()
{
   P3RawFile RawFile;

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CreateJumpFile(TRUE) );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.JumpToTime(0) );
   CPPUNIT_ASSERT( (INT64)369000000000 == RawFile.GetCurrentNanoSeconds() );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.JumpToTime(-1) );
   CPPUNIT_ASSERT( (INT64)872932000000 == RawFile.GetCurrentNanoSeconds() );

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.CloseFile() );
}

void RawFileTest::TestOrigFullDemoJump()
{
   P3RawFile RawFile;

   CopyFile(m_szDataDir + FULLDEMO_ORIG_JUMP, m_szDataDir + FULLDEMO_NEW_JUMP, FALSE);

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.OpenFile(m_szDataDir + FULLDEMO_RAW) );
   CPPUNIT_ASSERT( RawFile.DoesJumpExist() );

   CPPUNIT_ASSERT_SUCCEEDED( RawFile.JumpToTime(0) );
   CPPUNIT_ASSERT( (INT64)369000000000 == RawFile.GetCurrentNanoSeconds() );
   CPPUNIT_ASSERT_SUCCEEDED( RawFile.JumpToTime(-1) );
   CPPUNIT_ASSERT( (INT64)872932000000 == RawFile.GetCurrentNanoSeconds() );
}

// bSize == TRUE => Test that the 2 files are _exactly_ the same
// bSize == FALSE => Test that szFileA, if smaller, is equal to the first part of szFileB
const int READ_SIZE = 1000;
BOOL RawFileTest::CompareFiles(LPCTSTR szFileA, LPCTSTR szFileB, BOOL bSize)
{
   CFile fileA, fileB;
   BOOL bRet = TRUE;
   INT64 i64Position = 0;
   INT64 i64FirstDiff = 0;

   if (fileA.Open(szFileA, CFile::modeRead | CFile::shareDenyNone) == 0)
      bRet = FALSE;
   if (fileB.Open(szFileB, CFile::modeRead | CFile::shareDenyNone) == 0)
      bRet = FALSE;

   if (bRet && bSize)
      if (fileA.GetLength() != fileB.GetLength())
         return FALSE;

   BOOL bDone = FALSE;
   while (!bDone && bRet)
   {
      UINT n1, n2;
      char c1[READ_SIZE], c2[READ_SIZE];

      n1 = fileA.Read(c1, READ_SIZE);
      n2 = fileB.Read(c2, READ_SIZE);
      if (bSize && n1 != n2)
         bRet = FALSE;
      for (int x=0; x<n1 && bRet; x++)
      {
         if (c1[x] != c2[x])
         {
            i64FirstDiff = i64Position + x;
            bRet = FALSE;
         }
      }

      i64Position += n1;
      bDone = (n1 < READ_SIZE);
   }

   if (fileA.m_hFile != CFile::hFileNull)
      fileA.Close();
   if (fileB.m_hFile != CFile::hFileNull)
      fileB.Close();

   return bRet;
}
