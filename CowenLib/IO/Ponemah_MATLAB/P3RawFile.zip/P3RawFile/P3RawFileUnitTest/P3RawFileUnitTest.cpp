// P3RawFileUnitTest.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "P3RawFileUnitTest.h"


// CppUnit: MFC TestRunner
#include <cppunit/ui/mfc/TestRunner.h>
// CppUnit: TestFactoryRegistry to retreive the top test suite that contains all registered tests.
#include <cppunit/extensions/TestFactoryRegistry.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CP3RawFileUnitTestApp::CP3RawFileUnitTestApp()
{
}


CP3RawFileUnitTestApp theApp;


BOOL CP3RawFileUnitTestApp::InitInstance()
{
	SetRegistryKey(_T("PnmUnitTest"));  // Set Registry key to save previously run test suite
   
   // On startup, run test gui
   // Load test runner and start it up (load from registry)
   CPPUNIT_NS::MfcUi::TestRunner runner;
   runner.addTest( CPPUNIT_NS::TestFactoryRegistry::getRegistry().makeTest() );

   runner.run();

	return TRUE;
}
