// P3RawFileUnitTest.h : main header file for the P3RAWFILEUNITTEST application
//

#if !defined(AFX_P3RAWFILEUNITTEST_H__A6A7FD67_0B16_4162_8095_1EC79DFB1B89__INCLUDED_)
#define AFX_P3RAWFILEUNITTEST_H__A6A7FD67_0B16_4162_8095_1EC79DFB1B89__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CP3RawFileUnitTestApp:
// See P3RawFileUnitTest.cpp for the implementation of this class
//

class CP3RawFileUnitTestApp : public CWinApp
{
public:
	CP3RawFileUnitTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CP3RawFileUnitTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_P3RAWFILEUNITTEST_H__A6A7FD67_0B16_4162_8095_1EC79DFB1B89__INCLUDED_)
