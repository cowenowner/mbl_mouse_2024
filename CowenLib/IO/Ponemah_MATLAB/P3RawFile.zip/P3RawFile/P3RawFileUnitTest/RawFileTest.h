
#ifndef RAWFILE_TEST_H
#define RAWFILE_TEST_H

#include <cppunit/extensions/HelperMacros.h>

class RawFileTest : public CPPUNIT_NS::TestFixture
{

   CPPUNIT_TEST_SUITE( RawFileTest );
   CPPUNIT_TEST( Open_Close );
   CPPUNIT_TEST( TestFullDemoTime );
   CPPUNIT_TEST( TestFullDemoData );
   CPPUNIT_TEST( CreateJump );
   CPPUNIT_TEST( FullDemoJumpToTime );
   CPPUNIT_TEST( Extended2JumpToTime );
   CPPUNIT_TEST( WriteRawHeader );
   CPPUNIT_TEST( TestAcquisition );
   CPPUNIT_TEST( TestViewer );
   CPPUNIT_TEST( TestCalcDataTimes );
   CPPUNIT_TEST( TestJumpZero );
   CPPUNIT_TEST( TestOrigFullDemoJump );
   CPPUNIT_TEST_SUITE_END();

// Tests
protected:
   void Open_Close();
   void TestFullDemoTime();
   void TestFullDemoData();
   void CreateJump();
   void FullDemoJumpToTime();
   void Extended2JumpToTime();
   void WriteRawHeader();
   void TestAcquisition();
   void TestViewer();
   void TestCalcDataTimes();
   void TestJumpZero();
   void TestOrigFullDemoJump();


// Overrides
public:
   void        setUp ();
   void        tearDown ();

// Helper Functions
protected:
   void        DeleteUnwantedFiles();
   BOOL        CompareFiles(LPCTSTR szFileA, LPCTSTR szFileB, BOOL bSize=TRUE);

// Members
protected:
   CString     m_szDataDir;
};


#endif