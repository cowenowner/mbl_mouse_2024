#include "StdAfx.h"
#include <stdlib.h>
#include "JumpCache.h"
#include "P3RawFile.h"
#include "P3RawIncludes.h"


const int      BYTES_PER_SAMPLE     =  2;

/// Simple Constructor.
JumpCache::JumpCache(P3RawFile* pRawFile)
{
   m_pRawFile = pRawFile;
   m_bFullyCached = FALSE;
   m_ftLastWriteTime.dwHighDateTime = 0;
   m_ftLastWriteTime.dwLowDateTime = 0;
   m_pEntryArray = NULL;
   m_iEntryCount = 0;
   m_iEntryAllocCount = 0;
}


JumpCache::~JumpCache()
{
   if (m_pEntryArray)
      free(m_pEntryArray);
}


/// If older Raw File, there may be a sample time error propegating through the file
/// This will take an original start time and return the error offset
INT64 JumpCache::CalcError(INT64 i64OrigBlockStartTime)
{
   ////////////////////////////////////////////////////////////////////
   // Cycle through to find cached block matching the BlockPosition
   for (int iEntry=0; iEntry < m_iEntryCount; iEntry++)
   {
      if (m_pEntryArray[iEntry].i64StartTime == i64OrigBlockStartTime)
         return m_pEntryArray[iEntry].i64ErrOffset;
   }
   return 0;
}


/// Jump to the specified time.
/// \param i64Time Desired time to jump to
/// \return Position in file corresponding to the start of the block containing desired time
UINT64 JumpCache::Jump(INT64 i64Time)
{
   int iEntry = GetTableIndexByTime(i64Time);
   if (iEntry >= 0)
      return m_pEntryArray[iEntry].n64FilePos;
   return -1;   
}


/// Returns the Jump Table Entry index that contains the desired time.
int JumpCache::GetTableIndexByTime(INT64 i64Time)
{
   if (i64Time >= 0) // (-1) means cache the entire jump table, don't check the cache for this
   {
      int iCacheIndex = CacheJump(i64Time);
      if (iCacheIndex >= 0)
         return iCacheIndex;
   }

   // Update to get proper end of file
   m_pRawFile->UpdateFileStats();
   P3RawFile *pJumpTable = NULL;
   BOOL bCloseJump = FALSE;

   ////////////////////////////////////////////////////////////////////
   // Move to Jump Table or Open jump file
   if (m_pRawFile->m_RawHeader.bExtendedFile && (m_pRawFile->m_RawHeader.n64JumpTable != 0) )
   {
      // Point the JumpTable to this RawFile's jump table
      m_pRawFile->HugeSeek(m_pRawFile->m_RawHeader.n64JumpTable, FILE_BEGIN);
      pJumpTable = m_pRawFile;
   }
   else
   {
      HANDLE hTempHandle;
      HRESULT hr = m_pRawFile->m_pFileOpener->OpenFile(&hTempHandle, m_pRawFile->m_szJumpName, 
                     GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL);
      if (hTempHandle == INVALID_HANDLE_VALUE)
         return -1;

      // Slight hack here, use CRawFile for Jump file to use Read Functions
      // Copy header struct for raw file properties (so read functions will swap if necessary)
      pJumpTable = new P3RawFile();
      pJumpTable->m_hFile = hTempHandle;
      pJumpTable->m_RawHeader = m_pRawFile->m_RawHeader;

      bCloseJump = TRUE;
   }

   ////////////////////////////////////////////////////////////////////
   // If we are already fully cached, and jump file has not been modified, 
   // then that means requested time is greater than last jump entry (or is -1)
   // Therefore, return start of last block
   FILETIME ftLastWrite;
   GetFileTime(pJumpTable->m_hFile, NULL, NULL, &ftLastWrite);
   if (CompareFileTime(&m_ftLastWriteTime, &ftLastWrite) == 0 && m_bFullyCached)
   {
      if (bCloseJump)
      {
         CloseHandle(pJumpTable->m_hFile);
         pJumpTable->m_hFile = INVALID_HANDLE_VALUE;
         delete pJumpTable;
      }
      return m_iEntryCount-1;
   }

   // Save last modified time for next request
   m_ftLastWriteTime = ftLastWrite;
   
   ////////////////////////////////////////////////////////////////////
   // TODO: Right now, eliminating previous cache and recaching jump table
   // Should use previous cache to only cache necessary entries
   m_iEntryCount = 0;
   m_iEntryAllocCount = 50;
   m_pEntryArray = (JMPTBL_ENTRY*)realloc(m_pEntryArray, m_iEntryAllocCount * sizeof(JMPTBL_ENTRY));

   ////////////////////////////////////////////////////////////////////
   // Now, setup file to start jump caching
   LARGE_INTEGER Temp64;
   GetFileSizeEx(pJumpTable->m_hFile, &Temp64);
   UINT64 n64JumpEndPos = Temp64.QuadPart;

   UINT64 n64PreviousFilePosition = 0;
   UINT64 n64FilePosition = 0;
   UINT64 n64JumpPosition = 0;
   INT64 i64FileTime = -1;
   INT64 i64BlockEndTime = -1;

   INT64 i64TargetTime = i64Time;

   //////////////////////////////////
   // If we don't have an extended jump table, we only have 1 second resolution
   // We need to modify the TargetTime to reflect this, move it to 1 Nanosecond before earliest full second
   if (!m_pRawFile->m_RawHeader.bExtendedJump && (i64TargetTime != -1) )
   {
      i64TargetTime = (INT64)(i64TargetTime / NANO_FACTOR);
      i64TargetTime = (INT64)(i64TargetTime * NANO_FACTOR);
      i64TargetTime = max(0, i64TargetTime-1);
   }

   ////////////////////////////////////////////////////////////////////
   // Cycle through to find block containing time (if time is -1, get all entries)
   while ( ( (i64TargetTime < 0) || (i64FileTime < i64TargetTime) ) && (n64JumpPosition < n64JumpEndPos) )
   {
      // Save position from last block, will use once we pass the requested time
      n64PreviousFilePosition = n64FilePosition;
         
      // Read Jump Marker
      if (pJumpTable->ReadChar() != BLOCK_TIME_MARKER)
         return -1;

      // If Extended Jump, read in 8bit integers, otherwise, read in 4bit integers (CRawFile will swap if needed)
      if (m_pRawFile->m_RawHeader.bExtendedJump)
      {
         i64FileTime = pJumpTable->ReadInt64();
         i64BlockEndTime = pJumpTable->ReadInt64();
         n64FilePosition = pJumpTable->ReadInt64();
      }
      else if (m_pRawFile->m_RawHeader.bExtendedFile)
      {
         i64FileTime = pJumpTable->ReadLong() * NANO_FACTOR;
         n64FilePosition = ((DWORD)pJumpTable->ReadLong());
      }
      else
      {
         i64FileTime = pJumpTable->ReadLong() * NANO_FACTOR;
         n64FilePosition = ((DWORD)pJumpTable->ReadLong());
      }

      // Check position to see if we are at the end of the jump table
      n64JumpPosition = pJumpTable->HugeSeek(0, FILE_CURRENT);

      // The following condition is seen in some scheduled acquisitions (same entry listed twice)
      // If this occurs, do not add repeated entry
      if (m_iEntryCount == 0 || (n64FilePosition != m_pEntryArray[m_iEntryCount-1].n64FilePos) && (n64FilePosition < m_pRawFile->m_n64EndOfFile) )
      {
         JMPTBL_ENTRY JmpEntry;
         JmpEntry.i64StartTime = i64FileTime;
         JmpEntry.i64EndTime = i64BlockEndTime;
         JmpEntry.n64BlockSize = -1;
         JmpEntry.i64ErrOffset = 0;
         JmpEntry.n64FilePos = n64FilePosition;

         if (m_iEntryCount >= m_iEntryAllocCount)
         {
            m_iEntryAllocCount += 50;
            m_pEntryArray = (JMPTBL_ENTRY*)realloc(m_pEntryArray, m_iEntryAllocCount * sizeof(JMPTBL_ENTRY));
         }

         m_pEntryArray[m_iEntryCount] = JmpEntry;
         
         m_iEntryCount++;
      }

   }

   // If we have gone through every jump entry, mark as such
   if (n64JumpPosition >= n64JumpEndPos)
      m_bFullyCached = TRUE;

   ////////////////////////////////////////////////////////////////////
   // If we used a separate jump file, close it out and free memory
   if (bCloseJump)
   {
      CloseHandle(pJumpTable->m_hFile);
      pJumpTable->m_hFile = INVALID_HANDLE_VALUE;
      delete pJumpTable;
   }

   ////////////////////////////////////////////////////////////////////
   // If PrevPos is -1, then it is prior to first data block, set to first block
   if (n64PreviousFilePosition == 0)
      return 0;

   ////////////////////////////////////////////////////////////////////
   // If FileTime is still less than requested time, move to last block
   if (i64FileTime < i64TargetTime || i64TargetTime < 0)
      return m_iEntryCount-1;

   ////////////////////////////////////////////////////////////////////
   // Otherwise, it's the second to last block (we read the block that starts after the requested time)
   return m_iEntryCount-2;
}

/// Check to see if desired time is already cached, use that instead of re-opening file
int JumpCache::CacheJump(INT64 i64Time)
{
   if (m_iEntryCount == 0)
      return -1;

   ////////////////////////////////////////////////////////////////////
   // Binary Search
   int iLow = 0;
   int iHigh = (int)m_iEntryCount - 1;
   
   // If before first cached entry, return 0
   if (i64Time <= m_pEntryArray[0].i64StartTime)
      return 0;
   // If after last cached entry, return -1 (check to see if in last cache entry, if possible)
   if (i64Time > m_pEntryArray[iHigh].i64StartTime)
   {
      if (i64Time <= m_pEntryArray[iHigh].i64EndTime)
         return iHigh;
      return -1;
   }
   iHigh--;

   // Cycle until low is greater than requested and high is lower than requested
   // (Meaning the the 2 indexes will pass each other, high will be less than or equal to low)
   // Then, iHigh will be the requested index - the highest index that is before requested time
   while ( iHigh > iLow )
   {
      int iCurrent = (iLow + iHigh + 1) / 2;
      if (m_pEntryArray[iCurrent].i64StartTime <= i64Time)
         iLow = iCurrent;
      else
         iHigh = iCurrent - 1;
   }

   return iHigh;
}

/// Get current number of Jump Table Entries that are cached
int JumpCache::GetCacheCount()
{
   return m_iEntryCount;
}

/// Get the specified entry - a copy, any modifications will not be saved
void JumpCache::GetTableEntry(int iIndex, JMPTBL_ENTRY *pEntry)
{
   if (iIndex < m_iEntryCount)
      *pEntry = m_pEntryArray[iIndex];
}

/// Set the info of the specified cache entry
void JumpCache::SetTableEntryInfo(int iIndex, JMPTBL_ENTRY *pEntry)
{   
   // Calculate error - extra samples may be in raw file, account for error, accumulates through file
   if (iIndex > 0)
   {
      INT64 i64CorrectStart = m_pEntryArray[iIndex-1].i64EndTime + m_pEntryArray[iIndex-1].i64ErrOffset + m_pRawFile->m_RawHeader.i64TimeSlice;
      if (pEntry->i64StartTime < i64CorrectStart)
         pEntry->i64ErrOffset = i64CorrectStart - pEntry->i64StartTime;
   }

   m_pEntryArray[iIndex] = *pEntry;
}


// Copied from DataParser
INT64 JumpCache::CalcBlockEndTime(JMPTBL_ENTRY *pEntry, short sDivCount[])
{
   int         iChan, iNumSections;
   int         iNumMasterChans, iNumDiv1Chans, iNumDiv2Chans;  //Number of channels at the Master rate, Div1 and Div2
   DWORD       dwSize, dwSizeToBoundary;
   DWORD       dwDiv1Size;    //Number of bytes in Div1 time slices that include data acquired at the master rate and at Div1 rate
   DWORD       dwDiv2Size;    //Number of bytes in Div2 time slices that include data acquired at the master rate, Div1 rate and Div2 rate
   DWORD       dwDiv1, dwDiv2;  //The divisors   
   DWORD       dwNumTimeSlices, dwTSlicesToBoundary;
   int         iDiv1Count, iDiv2Count;    //Number of time slices before a rate1/rate2 boundary is reached

   iNumMasterChans        = 0;
   iNumDiv1Chans          = 0;
   iNumDiv2Chans          = 0;

   dwDiv1Size        = 0;
   dwDiv2Size        = 0;
   dwDiv1            = 0;
   dwDiv2            = 0;
   dwNumTimeSlices   = 0;

   //Step through the channels looking for channels at the different divisor settings.  When a new divisor setting 
   //is found, note the DivisorCount
   for(iChan=0; iChan < m_pRawFile->m_RawHeader.sNumChannels; iChan++)
   {
      //calculate the number of channels that are saved at each rate
      if(m_pRawFile->m_RawHeader.acType[iChan])
      {
         //Determine the divisors and the number of time slices required to reach a Div1 boundary and a Div2 boundary.
         if(1 != m_pRawFile->m_RawHeader.sDivisor[iChan] && 0 == dwDiv2)      //If not at the master rate and Div2 has not been set
         {
            if(0==dwDiv1)                                              //If Div1 has not been set
            {
               dwDiv1      = m_pRawFile->m_RawHeader.sDivisor[iChan];
               iDiv1Count  = sDivCount[iChan];
            }
         
            //This will not be used till the third sample rate is enabled
            if(dwDiv1 != (DWORD)m_pRawFile->m_RawHeader.sDivisor[iChan])                      //If the Divisor does not match Div1
            {
               dwDiv2      = m_pRawFile->m_RawHeader.sDivisor[iChan];
               iDiv2Count  = sDivCount[iChan];
               break;
            }
         }
      }
   }

   for(iChan=0; iChan < m_pRawFile->m_RawHeader.sNumChannels; iChan++)
   {
      //calculate the number of channels that are saved at each rate
      if(m_pRawFile->m_RawHeader.acType[iChan])
      {
         if(1 == m_pRawFile->m_RawHeader.sDivisor[iChan])
            iNumMasterChans++;
         
         if(dwDiv1 == (DWORD)m_pRawFile->m_RawHeader.sDivisor[iChan])
            iNumDiv1Chans++;

         if(dwDiv2 == (DWORD)m_pRawFile->m_RawHeader.sDivisor[iChan])
            iNumDiv2Chans++;
      }
   }

   dwSize         = (DWORD)pEntry->n64BlockSize;
   if(0==dwDiv1 && 0==dwDiv2)    //If we have only the master rate
   {
      dwNumTimeSlices   = dwSize/(iNumMasterChans * BYTES_PER_SAMPLE);
   }
   else     //we either have one or two divisors
   {
      //Determine data size to get to the closest Div1 boundary
      dwSizeToBoundary     = (iDiv1Count - 1) * iNumMasterChans * BYTES_PER_SAMPLE;  //Time slices to the boundary * size of data at master rate per slice
      dwTSlicesToBoundary  = iDiv1Count - 1;

      //Number of bytes in Div1 time slices that include data acquired at the master rate and at Div1 rate
      dwDiv1Size       = (iNumMasterChans * dwDiv1 + iNumDiv1Chans) * BYTES_PER_SAMPLE;    //Data size that incorporates Div1 time and 

      if(0==dwDiv2)    //If we have the master rate and one divisor
      {
         if(dwSize < dwSizeToBoundary)
         {
            //AfxMessageBox("DataParser, Size Mismatch");
         }
         else
         {
            //subtract the size to the boundary from the total
            dwSize           -= dwSizeToBoundary;
            dwNumTimeSlices   = dwTSlicesToBoundary;
      
            //Calculate the number of Div1 sections in the remaining data 
            iNumSections   = dwSize/dwDiv1Size;
            dwSize        -= iNumSections * dwDiv1Size;
            dwNumTimeSlices  += iNumSections * dwDiv1;

            if(dwSize)  //If more data exists
            {
               //The next Time slice will contain data at the slow rate and the master rate
               if((int)dwSize < (iNumMasterChans + iNumDiv1Chans) * BYTES_PER_SAMPLE)
               {
                  //AfxMessageBox("DataParser, Size Mismatch");
               }
               else
               {
                  dwNumTimeSlices++;
                  dwSize   -= (iNumMasterChans + iNumDiv1Chans) * BYTES_PER_SAMPLE;
               }
            }

            //The remaining data, if any, will be at the master sample rate
            dwNumTimeSlices  += dwSize/(iNumMasterChans * BYTES_PER_SAMPLE);
         }
      }
      else
      {
         //If a third sample rate exists and is not synced with the closest boundary
         if(iDiv2Count != iDiv1Count)
         {
            //We will have an integral number of blocks at Div1 before reaching a Div2 boundary
            dwSizeToBoundary    += ((iDiv2Count - iDiv1Count)/dwDiv1) * dwDiv1Size;
            dwTSlicesToBoundary += iDiv2Count - iDiv1Count;    //Add in the time slices to the boundary for Div2
         }

         //Number of bytes in Div2 time slices that include data acquired at the master rate, Div1 rate and Div2 rate
         dwDiv2Size       = dwDiv1Size * (dwDiv2/dwDiv1) + iNumDiv2Chans * BYTES_PER_SAMPLE;    //Data size that incorporates Div1 time and 

         if(dwSize < dwSizeToBoundary)
         {
            //ACM_TODO LATER - Add this message to the error list in the manual when 3 sample rates are supported
            //AfxMessageBox("DataParser, Size Mismatch");
         }
         else
         {
            //subtract the size to the boundary from the total
            dwSize           -= dwSizeToBoundary;
            dwNumTimeSlices   = dwTSlicesToBoundary;
      
            //Calculate the number of Div2 sections in the remaining data 
            iNumSections   = dwSize/dwDiv2Size;
            dwSize        -= iNumSections * dwDiv2Size;
            dwNumTimeSlices  += iNumSections * dwDiv2;

            //Calculate the number of Div1 sections in the remaining data 
            iNumSections   = dwSize/dwDiv1Size;
            dwSize        -= iNumSections * dwDiv1Size;
            dwNumTimeSlices  += iNumSections * dwDiv1;

            //The remaining data will be at the master sample rate
            dwNumTimeSlices  += dwSize/(iNumMasterChans * BYTES_PER_SAMPLE);
         }
      }
   }

   pEntry->i64EndTime = pEntry->i64StartTime + (dwNumTimeSlices - 1) * m_pRawFile->m_RawHeader.i64TimeSlice;
   
   return 0;
}