#pragma once

class P3RawFile;

/// Structure for storing Jump Table Entrys.
typedef struct
{
   ULONGLONG   n64FilePos;       ///< File Position of the block this entry points to
   INT64       i64StartTime;     ///< Starting time of the block (from the block, may be incorrect)
   INT64       i64EndTime;       ///< End time of the block (may be zero if older file, call Jump(-1) to calculate)
   ULONGLONG   n64BlockSize;     ///< Size of data block
   INT64       i64ErrOffset;     ///< If older file, this will show err of block start time (call Jump(-1) to calculate)
} JMPTBL_ENTRY;

/// Class to hold cached jump table entries
/// Will also correct block starting times of old files
class JumpCache
{
public:
	JumpCache(P3RawFile* pRawFile);
	virtual ~JumpCache();

   UINT64         Jump(INT64 i64Time);
   int            GetCacheCount();
   void           GetTableEntry(int iIndex, JMPTBL_ENTRY *pEntry);
   int            GetTableIndexByTime(INT64 i64Time);
   void           SetTableEntryInfo(int iIndex, JMPTBL_ENTRY *pEntry);
   INT64          CalcBlockEndTime(JMPTBL_ENTRY *pEntry, short sDivCount[]);
   INT64          CalcError(INT64 i64OrigBlockStartTime);

protected:
   int            CacheJump(INT64 i64Time);

protected:
   P3RawFile            *m_pRawFile;
   BOOL                 m_bFullyCached;
   FILETIME             m_ftLastWriteTime;
                        
   JMPTBL_ENTRY         *m_pEntryArray;
   int                  m_iEntryCount;
   int                  m_iEntryAllocCount;

};
