// P3RawFile.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include <stdlib.h>
#include <typeinfo.h>
#include <limits.h>
#include <float.h>
#include <time.h>


#include "P3RawFile.h"
#include "JumpCache.h"
#include "P3RawIncludes.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

/////////////////////////////////////////////////////////////////////////
/// Default class for FileOpener
class DefaultFileOpener : public P3FileOpener
{
public:
   HRESULT OpenFile(HANDLE* phFile, LPCTSTR szFileName, DWORD dwDesiredAccess, DWORD dwShareMode, 
                        DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes)
   {
      *phFile = CreateFile(szFileName, dwDesiredAccess, dwShareMode, NULL, dwCreationDisposition, dwFlagsAndAttributes, NULL);
      if (*phFile == INVALID_HANDLE_VALUE)
         return MAKE_WINERR;
      return S_OK;
   };

   HRESULT DeleteFile(LPCTSTR szFileName)
   {
      ::DeleteFile(szFileName);
      return S_OK;
   };
};


P3RawFile::P3RawFile()
{
   m_hJumpLock             = CreateEvent(NULL, TRUE, TRUE, NULL);
   m_hFile                 = INVALID_HANDLE_VALUE;
   m_hJumpFile             = INVALID_HANDLE_VALUE;
   m_szFileName            = NULL;
   m_szJumpName            = NULL;
   m_pFileOpener           = new DefaultFileOpener();
   m_pJumpCache            = NULL;
   m_pBlockData            = NULL;
   m_pDataStartTimeArray   = NULL;
   m_pDataEndTimeArray     = NULL;
   ResetMembers();
	return; 
}


P3RawFile::~P3RawFile()
{
   ResetMembers();

   /////////////////////////////////////////////////////////////////////////////////
   // If we have the default file opener, we need to delete it.
   // If one was passed in, it is up to the parent app to free the memory
   try
   {
      DefaultFileOpener *pDefault = dynamic_cast<DefaultFileOpener*>(m_pFileOpener);
      if (pDefault)
      {
         delete m_pFileOpener;
         m_pFileOpener = NULL;
      }
   }
   catch (__non_rtti_object)
   {
      // Do Nothing
   }
}


////////////////////////////////////////
/// Reset all state members to defaults
void P3RawFile::ResetMembers()
{
   if (m_szFileName)
   {
      free(m_szFileName);
      m_szFileName = NULL;
   }
   if (m_szJumpName)
   {
      free(m_szJumpName);
      m_szJumpName = NULL;
   }
   if (m_hFile != INVALID_HANDLE_VALUE)
   {
      CloseHandle(m_hFile);
      m_hFile = INVALID_HANDLE_VALUE;
   }
   if (m_hJumpFile != INVALID_HANDLE_VALUE)
   {
      CloseHandle(m_hJumpFile);
      m_hJumpFile = INVALID_HANDLE_VALUE;
   }
   if (m_pJumpCache)
   {
      delete m_pJumpCache;
      m_pJumpCache = NULL;
   }
   if (m_pBlockData)
   {
      free(m_pBlockData);
      m_pBlockData = NULL;
   }
   if (m_pDataStartTimeArray)
   {
      free(m_pDataStartTimeArray);
      m_pDataStartTimeArray = NULL;
   }
   if (m_pDataEndTimeArray)
   {
      free(m_pDataEndTimeArray);
      m_pDataEndTimeArray = NULL;
   }
   m_n64EndOfFile = 0;
   m_n64BlockHeaderSize = 0;
   m_i64CurElapsedTime = 0;
   m_iRawFileMode = RAWFILE_NONE;
   m_bCancelCreateJump = FALSE;
   m_RawHeader.bValid = FALSE;
   m_BlockHeader.bValid = FALSE;
   m_BlockHeader.pData = NULL;
   m_iDesiredBlockSize = 0;
   m_fJumpFilePerc = -1;
   m_ftLastCalcData.dwHighDateTime = 0;
   m_ftLastCalcData.dwLowDateTime = 0;
   m_iDataTimeCount = 0;
   m_iDataTimeAlloc = 0;
   for (int x=0; x<RAWFILE_MAX_CHANNELS; x++)
      m_bInterestedChan[x] = TRUE;
}

UINT64 P3RawFile::HugeSeek(INT64 i64DistanceToMove, DWORD dwMoveMethod)
{
   LARGE_INTEGER li;

   li.QuadPart = i64DistanceToMove;

   li.LowPart = SetFilePointer(m_hFile, li.LowPart, &li.HighPart, dwMoveMethod);

   if(li.LowPart == INVALID_SET_FILE_POINTER && GetLastError() != NO_ERROR)
   {
      li.QuadPart = -1;
   }

   return li.QuadPart;
}

HRESULT P3RawFile::OpenFile(LPCTSTR szFileName)
{
   HRESULT hr;
   
   if (m_hFile != INVALID_HANDLE_VALUE)
      RETURN_ERR(RAWERR_FILE_ALREADY_OPEN);

   ResetMembers();

   // Open file
   HANDLE hTemp = INVALID_HANDLE_VALUE;
   hr = m_pFileOpener->OpenFile(&hTemp, szFileName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL);

   // If failed, try without getting write access
   if (hr != S_OK)
      hr = m_pFileOpener->OpenFile(&hTemp, szFileName, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL);

   if (hr != S_OK)
      return hr;

   m_hFile = hTemp;

   // Save File Name
   m_szFileName = (char*)malloc((strlen(szFileName)+1) * sizeof(char));
   strncpy(m_szFileName, szFileName, strlen(szFileName)+1);

   // Create and Save Jump Name
   m_szJumpName = (char*)malloc((strlen(szFileName)+1) * sizeof(char));
   strncpy(m_szJumpName, szFileName, strlen(szFileName)-3);
   m_szJumpName[strlen(szFileName)-3] = '\0';
   strcat(m_szJumpName, "JMP");

   LARGE_INTEGER Temp64;
   GetFileSizeEx(m_hFile, &Temp64);
   m_n64EndOfFile = Temp64.QuadPart;

   HugeSeek(0, FILE_BEGIN);

   m_iRawFileMode = RAWFILE_READING;

   // Initialize Jump Cache
   m_pJumpCache = new JumpCache(this);

   CHECK_RETURN( ReadRawHeader() );
   CHECK_RETURN( ReadBlockHeader(TRUE) );
   return S_OK;
}


////////////////////////////////////////
/// Close the Raw File
HRESULT P3RawFile::CloseFile()
{
   // If Acquiring, Write last block of data and append jump
   if (m_iRawFileMode == RAWFILE_WRITING)
   {
      if (m_BlockHeader.bValid)
         WriteBlock();
      AppendJump();
   }

   if (m_hFile != INVALID_HANDLE_VALUE)
   {
      CloseHandle(m_hFile);
      m_hFile = INVALID_HANDLE_VALUE;
   }

   return S_OK;
}

BOOL P3RawFile::IsOpen()
{
   return (m_hFile != INVALID_HANDLE_VALUE);
}

////////////////////////////////////////
/// Reads the Raw Header and saves all Raw File specific data
HRESULT P3RawFile::ReadRawHeader()
{
   if (m_hFile == INVALID_HANDLE_VALUE)
      RETURN_ERR (RAWERR_FILE_NOT_OPEN);

   DWORD dwBytesRead;

   // Get end of file position (Data may be added by another app)
   LARGE_INTEGER Temp64;
   GetFileSizeEx(m_hFile, &Temp64);
   m_n64EndOfFile = Temp64.QuadPart;

   // Read FileID
   if (!ReadFile(m_hFile, &m_RawHeader.lFileID, 4, &dwBytesRead, NULL))
      return MAKE_WINERR;

   // If old file, swap the header
   if (m_RawHeader.lFileID != RAWFILE_EXTENDED && m_RawHeader.lFileID != RAWFILE_EXTENDED2)
      m_RawHeader.lFileID = SwapLong(m_RawHeader.lFileID);

   // Setup channels according to FileID
   switch (m_RawHeader.lFileID)
   {
      case RAWFILE_APPEND:
      break;

      case RAWFILE_ID_16:
         m_RawHeader.bExtendedFile  = FALSE;
         m_RawHeader.bOldRawFile    = TRUE;
         m_RawHeader.sNumChannels   = 16;
      break;

      case RAWFILE_ID_8:
         m_RawHeader.bExtendedFile  = FALSE;
         m_RawHeader.bOldRawFile    = TRUE;
         m_RawHeader.sNumChannels   = 8;
      break;

      case RAWFILE_NEW_ID16:
         m_RawHeader.bExtendedFile  = FALSE;
         m_RawHeader.bOldRawFile    = FALSE;
         m_RawHeader.sNumChannels   = 16;
      break;

      case RAWFILE_NEW_ID8:
         m_RawHeader.bExtendedFile  = FALSE;
         m_RawHeader.bOldRawFile    = FALSE;
         m_RawHeader.sNumChannels   = 8;
      break;

      case RAWFILE_EXTENDED:
      case RAWFILE_EXTENDED2:
         m_RawHeader.bExtendedFile  = TRUE;
         m_RawHeader.bOldRawFile    = FALSE;
      break;

      default:
         RETURN_ERR (RAWERR_RAWHEADER_NOT_VALID);
   }

   // Get Date and Time
   m_RawHeader.lDate = ReadLong();
   m_RawHeader.lTime = ReadLong();

   // all except EXTENDED2 files store the jump table here as a DWORD
   m_RawHeader.n64JumpTable = (INT64)ReadLong();

   ReadString(m_RawHeader.szUserName, 40);

   int iFillerBytes = FILLER_LENGTH;

   // With RAW_FILE_EXTENDED2 files, the Jump information is available here as an 8 byte int
   m_RawHeader.bExtendedJump = FALSE;
   if (RAWFILE_EXTENDED2 == m_RawHeader.lFileID)
   {
      m_RawHeader.n64JumpTable = ReadInt64();
      iFillerBytes -= sizeof(m_RawHeader.n64JumpTable);
      m_RawHeader.bExtendedJump = TRUE;
   }
   
   // Filler bytes
   ReadString(NULL, iFillerBytes);

   // Reset end of file so we dont run into Jump file
   if (m_RawHeader.bExtendedFile && m_RawHeader.n64JumpTable)
      m_n64EndOfFile = m_RawHeader.n64JumpTable-1;

   float fRate;
   if (m_RawHeader.bOldRawFile)
      ReadLong();                // make sure that float does not cause a problem     
   else
      fRate = ReadFloat();       // could be float sample rate

   DWORD dwTS;
   if (m_RawHeader.bExtendedFile)
      dwTS = ReadLong();
   else
      dwTS = ReadShort();

   m_RawHeader.i64TimeSlice = dwTS * (NANO_FACTOR/10000);  //Time in ns between samples at the highest sampled rate
   m_RawHeader.fRate = m_RawHeader.bOldRawFile ? (float)(1.0 / ((double)dwTS * 0.0001)) : fRate;

   m_RawHeader.sAD_Serial  = ReadShort();
   m_RawHeader.sCP_Serial  = ReadShort();
   m_RawHeader.cGroups     = ReadChar();

   if (m_RawHeader.bExtendedFile)   // number channels in file format
      m_RawHeader.sNumChannels = ReadShort();

   // Read channel info
   m_RawHeader.iNumActive = 0;
   for (int iChan=0; iChan < m_RawHeader.sNumChannels; iChan++)
   {
      m_RawHeader.acType[iChan] = ReadChar();
      if (m_RawHeader.acType[iChan])
      {
         m_RawHeader.iSampleIndex[iChan] = m_RawHeader.iNumActive;  //The number of active channels prior to the iChan
         m_RawHeader.iNumActive++;
      }

      m_RawHeader.acDecimal[iChan]     = ReadChar();
      m_RawHeader.sDivisor[iChan]      = ReadShort();
      if( !m_RawHeader.sDivisor[iChan])
         m_RawHeader.sDivisor[iChan]   = 1;
      m_RawHeader.afHighCal[iChan]     = ReadFloat();
      m_RawHeader.afLowCal[iChan]      = ReadFloat();
   }

   // setup defaults for other channels
   while (iChan < RAWFILE_MAX_CHANNELS)
   {
      m_RawHeader.acType[iChan]      = 0;
      m_RawHeader.acDecimal[iChan]   = 0;
      m_RawHeader.sDivisor[iChan]    = 1;
      iChan++;
   }

   // Read group info (??)
   for (iChan=0; iChan < m_RawHeader.sNumChannels; iChan++)
   {
      m_RawHeader.Group[0][iChan].AD_High  = ReadShort();
      m_RawHeader.Group[0][iChan].AD_Low   = ReadShort();
      m_RawHeader.Group[0][iChan].Scale    = ReadFloat();
      ReadString(m_RawHeader.Group[0][iChan].ChanID, 9);

      // If old style file, these variables do nothing - but can cause problems when copying from old to new
      if (!m_RawHeader.bExtendedFile)
      {
         m_RawHeader.Group[0][iChan].AD_High  = 0;
         m_RawHeader.Group[0][iChan].AD_Low   = 0;
      }
   }

   // Set Block Header size
   m_n64BlockHeaderSize = 2*m_RawHeader.sNumChannels + 14 + ( (m_RawHeader.lFileID == RAWFILE_EXTENDED2) ? 8 : 0);


   m_RawHeader.n64RawHeaderLength = HugeSeek(0, FILE_CURRENT);
   m_RawHeader.bValid = TRUE;

   CalcScalingVars();

   return S_OK;
}


////////////////////////////////////////
/// Reads the Block Header directly from the current position within the file.
/// \param[in] bReadData If TRUE, reads in the associated data block, otherwise moves the file position to the end of the block
HRESULT P3RawFile::ReadBlockHeader(LONG bReadData)
{   
   if (m_hFile == INVALID_HANDLE_VALUE)      RETURN_ERR (RAWERR_FILE_NOT_OPEN);
   if (!m_RawHeader.bValid)                  RETURN_ERR (RAWERR_RAWHEADER_NOT_VALID);

   DWORD dwErr = 0;

   UINT64 n64Position = HugeSeek(0, FILE_CURRENT);

   // Check to see if we are at the end of the file
   if (n64Position >= m_n64EndOfFile)
      RETURN_ERR (RAWERR_NO_MORE_BLOCKS);
   
   // Cache block header
   DWORD dwBytesRead;
   char *pBlockHeader = (char*)malloc((int)m_n64BlockHeaderSize);
   ReadFile(m_hFile, pBlockHeader, (int)m_n64BlockHeaderSize, &dwBytesRead, NULL);

   CHECK_RETURN( ReadBlockHeaderMem(pBlockHeader) );

   //Problems with cut data from 8536089a.RAW, see (8536089a 1 hour.RAW and RVW), the size of the RAW file indicates that
   //there is another block available, however, the information read out of it is erroneous
   //Unable to re-create this error
   n64Position = HugeSeek(0, FILE_CURRENT);
   if ( (n64Position + m_BlockHeader.dwDataSize) > (m_n64EndOfFile + 1) )
      RETURN_ERR( RAWERR_NO_MORE_BLOCKS );

   /////////////////////////////////////////////////////
   // Read Data
   m_BlockHeader.dwDataPos = 0;
   if (m_BlockHeader.dwDataSize > 0 && bReadData)
   {
      // If previously allocated, realloc
      m_pBlockData = (char*)realloc(m_pBlockData, m_BlockHeader.dwDataSize);
      
      DWORD dwBytesRead;
      ReadFile(m_hFile, m_pBlockData, m_BlockHeader.dwDataSize, &dwBytesRead, NULL);
      if (dwBytesRead != m_BlockHeader.dwDataSize)
         RETURN_ERR( RAWERR_UNEXPECTED_END_OF_FILE );

      m_BlockHeader.pData = m_pBlockData;
   } 
   else  // Clear out buffer so no mistakes are made
   {
      m_BlockHeader.pData = NULL;
      HugeSeek(m_BlockHeader.dwDataSize, FILE_CURRENT);
   }

   free(pBlockHeader);

   return S_OK;
}

HRESULT P3RawFile::ReadBlockHeaderMem(char* pBuffer)
{
   char* pCurBuffer = pBuffer;

   // Read elapsed time or, if appended, read raw header
   LONG bBlockHeader = FALSE;
   long lElapsedTime = 0;
   while (!bBlockHeader)
   {
      lElapsedTime = BufferReadLong(&pCurBuffer);
      if (lElapsedTime == RAWFILE_APPEND)
      {
         RETURN_ERR( RAWERR_APPEND_NOT_SUPPORTED ); // Append not supported for now
         //m_pFile->Seek(-4, CFile::current);
         //DWORD dwErr = ReadRawHeader();
         //if (dwErr != 0)
         //   RETURN_ERR (dwErr);
      }
      else
         bBlockHeader      = TRUE;
   }

   m_BlockHeader.dwElapsedTime = lElapsedTime;

   switch (m_RawHeader.lFileID)
   {
      case RAWFILE_APPEND:
      break;

      case RAWFILE_ID_8:
      case RAWFILE_ID_16:    //ms resolution
         m_BlockHeader.dwNanoSeconds      = (DWORD)(BufferReadLong(&pCurBuffer) * DELTA_TICK_RES);
      break;

      case RAWFILE_NEW_ID16:
      case RAWFILE_NEW_ID8:  //float resolution
         m_BlockHeader.dwNanoSeconds      = (DWORD)(BufferReadFloat(&pCurBuffer) * (float)(INT64)NANO_FACTOR);
      break;

      case RAWFILE_EXTENDED: //ns resolution
         m_BlockHeader.dwNanoSeconds      = BufferReadLong(&pCurBuffer);
      break;

      case RAWFILE_EXTENDED2:
         m_BlockHeader.dwNanoSeconds      = BufferReadLong(&pCurBuffer);
         m_BlockHeader.i64EndBlockTime    = BufferReadInt64(&pCurBuffer);
      break;
   }

   m_i64CurElapsedTime = lElapsedTime * NANO_FACTOR + m_BlockHeader.dwNanoSeconds;
   m_i64CurElapsedTime += m_pJumpCache->CalcError(m_i64CurElapsedTime);

   m_BlockHeader.dwDataSize = BufferReadLong(&pCurBuffer);

   m_BlockHeader.cGroup = BufferReadChar(&pCurBuffer);

   for (int iChan=0; iChan < m_RawHeader.sNumChannels; iChan++)
   {
      m_BlockHeader.sDivisorCount[iChan] = BufferReadShort(&pCurBuffer);

      // NOTE DivisorCount should never be less than or == 0.  Some ACQ7700 files from 4.00 and earlier may show
      // this problem if the Calibration dialog was opened prior to starting acquisition. In the 7700 all samples 
      // line up at startup so DivisorCount should have a value of 1
      if (m_BlockHeader.sDivisorCount[iChan] <= 0)
         m_BlockHeader.sDivisorCount[iChan]  = 1;

      m_sDivisorCount[iChan] = m_BlockHeader.sDivisorCount[iChan];
   }

   m_BlockHeader.cFirstChan = BufferReadChar(&pCurBuffer);

   m_BlockHeader.bValid = TRUE;

   return S_OK;
}


/// Calculate and store scaling data for each channel.
/// This is done to improve speed, changes 4 float operations down to 2 for each scaling calculation
void P3RawFile::CalcScalingVars()
{
   // Setup Scaling vars
   for (int iChan=0; iChan < m_RawHeader.sNumChannels; iChan++)
   {
      m_fScaleVal[iChan]      = m_RawHeader.Group[0][iChan].Scale * FloatFactor[m_RawHeader.acDecimal[iChan]];
      SHORT sADLow            = m_RawHeader.bExtendedFile ? (int)m_RawHeader.Group[0][iChan].AD_Low : 0;
      m_fScaleLowCal[iChan]   = m_RawHeader.afLowCal[iChan] - (m_fScaleVal[iChan] * sADLow);
   }
}

HRESULT P3RawFile::SetFileOpener(P3FileOpener* pOpener)
{
   // Release previous opener
   if (m_pFileOpener != NULL)
      delete m_pFileOpener;

   if (pOpener == NULL)
      m_pFileOpener = new DefaultFileOpener();
   else
      m_pFileOpener = pOpener;

   return S_OK;
}

/// Update the current status of the file.
/// Check to see if the end of the file has been modified
void P3RawFile::UpdateFileStats()
{
   UINT64 n64Position = HugeSeek(0, FILE_CURRENT);

   LARGE_INTEGER Temp64;
   GetFileSizeEx(m_hFile, &Temp64);
   m_n64EndOfFile = Temp64.QuadPart;

   if (m_RawHeader.bExtendedFile && (m_RawHeader.n64JumpTable == 0) )
   {
      // See if jump table has been appended (may be in Viewer mode, and original ACQ may have ended)
      if (m_RawHeader.bExtendedJump)
      {
         HugeSeek(EXT_JMP_OFFSET, FILE_BEGIN); 
         m_RawHeader.n64JumpTable = ReadInt64();
      }
      else
      {
         HugeSeek(OLD_JMP_OFFSET, FILE_BEGIN);
         m_RawHeader.n64JumpTable = ReadLong();
      }
   }

   // Reset end of file so we dont run into Jump file
   if (m_RawHeader.bExtendedFile && m_RawHeader.n64JumpTable)
      m_n64EndOfFile = m_RawHeader.n64JumpTable-1;
   
   HugeSeek(n64Position, FILE_BEGIN); 
}

HRESULT P3RawFile::GetNextSampleScaled(float* pSignals, int iCount)
{
   short Samples[RAWFILE_MAX_CHANNELS];
   CHECK_RETURN( GetNextSampleUnscaled(Samples, iCount) );

   for (int iChan=0; iChan < iCount; iChan++)
      pSignals[iChan] = m_bInterestedChan[iChan] ? ScaleData(iChan, Samples[iChan]) : FLT_MIN;

   return S_OK;
}

HRESULT P3RawFile::GetNextSampleUnscaled(short* pSamples, int iCount)
{
   if (!m_RawHeader.bValid)
      RETURN_ERR( RAWERR_RAWHEADER_NOT_VALID );

   /////////////////////////////////////////////////////////
   // Make sure we have valid data
   if (!m_BlockHeader.bValid || m_BlockHeader.dwDataPos >= m_BlockHeader.dwDataSize)
   {
      // See if we're at the end
      UINT64 n64Position = HugeSeek(0, FILE_CURRENT);
      if (n64Position >= m_n64EndOfFile)
      {
         // See if data has been added - Update, get's new file end and jump file, if appended
         UpdateFileStats();
         if (n64Position >= m_n64EndOfFile)
            RETURN_ERR (RAWERR_NO_MORE_BLOCKS);
      }
      
      // Move to next block
      CHECK_RETURN( ReadBlockHeader(TRUE) );
   }

   short sTempArray[RAWFILE_MAX_CHANNELS];

   // Cycle through the channels
   for (int iChan=0; iChan < m_RawHeader.sNumChannels; iChan++)
   {
      sTempArray[iChan] = SHRT_MIN;
      // If channel is enabled in RAW
      if (m_RawHeader.acType[iChan])
      {
         // See if Divisor is set to take this channel's sample
         m_sDivisorCount[iChan]--;
         if (m_sDivisorCount[iChan] == 0)
         {
            // If interested in channel, get the data
            if (m_bInterestedChan[iChan])
            {
               short sData;
               char* pDataPos = (m_BlockHeader.pData + m_BlockHeader.dwDataPos);
               
               // Read Sample
               if (m_RawHeader.bExtendedFile)
               {
                  sData = *((short *)pDataPos);
               }
               else
               {
                  char hi = *(pDataPos);
                  char lo = *(pDataPos+1);
               
                  sData = (((short)hi << 8) | ((short)lo & 0x00ff));
               }
            
               // If data point actually is SHRT_MIN, make it SHRT_MIN+1
               sTempArray[iChan] = (sData == SHRT_MIN) ? SHRT_MIN+1 : sData;
            }
            
            // Advance position & Reset Divisor (whether interested or not)
            m_sDivisorCount[iChan] = m_RawHeader.sDivisor[iChan];
            m_BlockHeader.dwDataPos += 2;
         }
      }
      if (iChan < iCount)
         pSamples[iChan] = sTempArray[iChan];
   }

   /////////////////////////////////////////////////////////
   // Advance Time
   if (m_BlockHeader.dwDataPos >= m_BlockHeader.dwDataSize)
   {
      // See if we're at the end
      UINT64 n64Position = HugeSeek(0, FILE_CURRENT);
      if (n64Position >= m_n64EndOfFile)
      {
         // See if data has been added - Update, get's new file end and jump file, if appended
         UpdateFileStats();
         if (n64Position >= m_n64EndOfFile)
            return S_OK; // just return OK, do not advance time
      }
      
      // Move to next block - reading block header will modify the time
      CHECK_RETURN( ReadBlockHeader(TRUE) );
   }
   else // advance time by one frame step
      m_i64CurElapsedTime += (INT64)(NANO_FACTOR / m_RawHeader.fRate);

   return S_OK;
}


/// Scale the given unscaled data point - uses pre-calculated scaling numbers (see CalcScalingVars())
/// \param iChan Channel that the data point represents
/// \param sData Unscaled data point to be scaled
/// \return Scaled float
float P3RawFile::ScaleData(int iChan, short sData)
{
   if (sData == SHRT_MIN)
      return FLT_MIN;
   return (m_fScaleVal[iChan] * sData) + m_fScaleLowCal[iChan];
}

/// Unscale the given scaled data point - uses pre-calculated scaling numbers (see CalcScalingVars()).
/// \param iChan Channel that the data point represents
/// \param fSignal Scaled data point to be unscaled
/// \return Unscaled short
short P3RawFile::UnscaleData(int iChan, float fSignal)
{
   if (fSignal == FLT_MIN || m_RawHeader.acType[iChan] == 0)
      return SHRT_MIN;

   float fVal = (fSignal - m_fScaleLowCal[iChan]) / m_fScaleVal[iChan];

   // round off
   fVal += (fVal > 0) ? (float)0.5 : (float)-0.5;
   short sData = (short)(fVal);

   if (iChan == 0)
      int g=0;
   
   return sData;
}

BOOL P3RawFile::DoesJumpExist()
{
   UpdateFileStats(); // To see if jump file has been appended

   // If Extended and jump table, return true
   // If extended and no jump table, check for accompanying file (may be viewer, with raw still in ACQ)
   if (m_RawHeader.bExtendedFile && (m_RawHeader.n64JumpTable != 0) )
      return TRUE;
   
   // Otherwise, Old raw file or possibly in viewer, check for accompanying jmp file
   HANDLE hTempHandle;
   HRESULT hr = m_pFileOpener->OpenFile(&hTempHandle, m_szJumpName, GENERIC_READ, 
                              FILE_SHARE_READ | FILE_SHARE_WRITE, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL);

   if (hTempHandle == INVALID_HANDLE_VALUE)
      return FALSE;
   
   CloseHandle(hTempHandle);
   return TRUE; 
}

/// Create a jump file for the current Raw File.
/// This will create a new jump file, overwriting any old jump file, for the current Raw File.
/// If an older file, this will create a separate jump file.  If newer, will append the jump to the Raw.
/// /param bSynchronous If TRUE, function will wait until completeion to return.  If FALSE, 
/// will return immediately, allowing GetJumpProgress to check the progress.
HRESULT P3RawFile::CreateJumpFile(BOOL bSynchronous)
{
   // If synchrounous, call the static function directly then return.
   if (bSynchronous)
   {
      CreateJumpFileProc((void*) this);
      return S_OK;
   }

   // if asynchrounous, spawn a thread to create the jump file
   ULONG nID;
   HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)&CreateJumpFileProc, (void*)this, CREATE_SUSPENDED, &nID);
   ResumeThread(hThread);

   return S_OK;
}

/// Static function for create jump thread
UINT P3RawFile::CreateJumpFileProc(LPVOID pInfo)
{
   P3RawFile* pRawFile = (P3RawFile*)pInfo;

   pRawFile->m_bCancelCreateJump = FALSE;

   // Create a new Jump File
   HANDLE hTempHandle;
   HRESULT hr = pRawFile->m_pFileOpener->OpenFile(&hTempHandle, pRawFile->m_szJumpName, 
                     GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL);
   if (hTempHandle == INVALID_HANDLE_VALUE)
      return 0;

   pRawFile->m_hJumpFile = hTempHandle;

   // Move to first block header
   pRawFile->HugeSeek(pRawFile->m_RawHeader.n64RawHeaderLength, FILE_BEGIN);
   
   while (!pRawFile->m_bCancelCreateJump)
   {
      DWORD dwBytesWritten;
      char szJumpLine[MAX_PATH];

      // Get File position
      UINT64 n64Position = pRawFile->HugeSeek(0, FILE_CURRENT);
      DWORD dwFilePosition = (DWORD)n64Position;

      // Set Percent Complete
      WaitForSingleObject(pRawFile->m_hJumpLock, INFINITE);
      ResetEvent(pRawFile->m_hJumpLock);
      pRawFile->m_fJumpFilePerc = ((double)(INT64)pRawFile->m_n64EndOfFile / (double)(INT64)n64Position);
      SetEvent(pRawFile->m_hJumpLock);

      // Read Block
      hr = pRawFile->ReadBlockHeader(FALSE);
      if (!SUCCEEDED(hr))
         break;
      
      // Set start of jump line
      szJumpLine[0] = BLOCK_TIME_MARKER;

      if (!pRawFile->m_RawHeader.bExtendedFile)
      {
         long lValue = SwapLong(pRawFile->m_BlockHeader.dwElapsedTime);     // elapsed time of entry
         memcpy(&szJumpLine[1], &lValue, 4);
         lValue = SwapLong(dwFilePosition);                       // position in file
         memcpy(&szJumpLine[5], &lValue, 4);
         WriteFile(pRawFile->m_hJumpFile, szJumpLine, 9, &dwBytesWritten, NULL);
      }
      else if(!pRawFile->m_RawHeader.bExtendedJump)
      {
         long lValue = pRawFile->m_BlockHeader.dwElapsedTime;     // elapsed time of entry
         memcpy(&szJumpLine[1], &lValue, 4);
         lValue = dwFilePosition;                                 // position in file
         memcpy(&szJumpLine[5], &lValue, 4);
         WriteFile(pRawFile->m_hJumpFile, szJumpLine, 9, &dwBytesWritten, NULL);
      }
      else // use 8 byte JUMP
      {
         INT64 i64BlockTime = (INT64)((pRawFile->m_BlockHeader.dwElapsedTime * (INT64)NANO_FACTOR) + pRawFile->m_BlockHeader.dwNanoSeconds);
         int iBlockOffset = 1;

         memcpy(&szJumpLine[iBlockOffset], &i64BlockTime, sizeof(INT64));
         iBlockOffset += sizeof(INT64);
         memcpy(&szJumpLine[iBlockOffset], &pRawFile->m_BlockHeader.i64EndBlockTime, sizeof(INT64));
         iBlockOffset += sizeof(INT64);
         memcpy(&szJumpLine[iBlockOffset], &n64Position, sizeof(INT64));
         iBlockOffset += sizeof(INT64);

         WriteFile(pRawFile->m_hJumpFile, szJumpLine, iBlockOffset, &dwBytesWritten, NULL);
      }

   }

   LARGE_INTEGER Temp64;
   GetFileSizeEx(pRawFile->m_hJumpFile, &Temp64);
   UINT64 n64JumpSize = Temp64.QuadPart;

   // If extended file, append JMP file onto raw file (will automatically close jump)
   if (!pRawFile->m_bCancelCreateJump && pRawFile->m_RawHeader.bExtendedFile && n64JumpSize > 0)
   {
      pRawFile->AppendJump();
   }
   else // close out jump file
   {
      CloseHandle(pRawFile->m_hJumpFile);
      pRawFile->m_hJumpFile = INVALID_HANDLE_VALUE;
   }

   pRawFile->m_fJumpFilePerc = 1;

   return 0;
}


/// APpend the jump file to the raw file - Only for new Raw Files
HRESULT P3RawFile::AppendJump()
{
   if (m_hFile == INVALID_HANDLE_VALUE)         return RAWERR_FILE_NOT_OPEN;
   if (m_hJumpFile == INVALID_HANDLE_VALUE)     return RAWERR_JUMPFILE_ERROR;

   // Save end location
   UINT64 n64FilePosition = HugeSeek(0, FILE_CURRENT);
   DWORD dwFilePosition = (DWORD)n64FilePosition;

   UINT64 n64JumpSize = SetFilePointer(m_hJumpFile, 0, 0, FILE_CURRENT);
   DWORD dwJumpSize = (DWORD)n64JumpSize;

   DWORD dwBytes;

   if (dwJumpSize)
   {
      char *pJumpData = (char*)malloc(dwJumpSize);
      if (!pJumpData)
         RETURN_ERR (RAWERR_JUMPFILE_ERROR);

      // Append Jump to RAW
      SetFilePointer(m_hJumpFile, 0, 0, FILE_BEGIN);
      ReadFile(m_hJumpFile, pJumpData, dwJumpSize, &dwBytes, NULL);
      WriteFile(m_hFile, pJumpData, dwJumpSize, &dwBytes, NULL);
      free(pJumpData);
   }

   // Write position into RAW header
   if (m_RawHeader.bExtendedJump)
   {
      HugeSeek(EXT_JMP_OFFSET, FILE_BEGIN); 
      WriteFile(m_hFile, &n64FilePosition, 8, &dwBytes, NULL);
   }
   else
   {
      HugeSeek(OLD_JMP_OFFSET, FILE_BEGIN); 
      WriteFile(m_hFile, &n64FilePosition, 4, &dwBytes, NULL);
   }

   // set RawHeader
   m_RawHeader.n64JumpTable = n64FilePosition;

   // Close Jump file
   CloseHandle(m_hJumpFile);
   m_hJumpFile = INVALID_HANDLE_VALUE;

   m_pFileOpener->DeleteFile(m_szJumpName);

   return S_OK;
}

/// Jump to a specific time in the Raw File.
/// Will jump to the specified time.  If time is prior to any acquired data, will jump to the
/// beginning of the file.  If time is after all acquired data, will jump to the end of the file.
HRESULT P3RawFile::JumpToTime(INT64 i64Time)
{
   DWORD dwErr = 0;

   if (!DoesJumpExist())
      RETURN_ERR( RAWERR_NO_JUMP );

   ////////////////////////////////////////////////////////////////////
   // Get block to jump to from cache
   UINT64 n64JumpToPosition = m_pJumpCache->Jump(i64Time);
   if (n64JumpToPosition < 0)
      RETURN_ERR( RAWERR_JUMPFILE_ERROR );

   ////////////////////////////////////////////////////////////////////
   // search to desired time point
   HugeSeek(n64JumpToPosition, FILE_BEGIN);
   CHECK_RETURN( ReadBlockHeader(TRUE) );

   ////////////////////////////////////////////////////////////////////
   // Cycle through samples until we reach end of file or desired time (if -1, cycle until end)
   HRESULT hr = S_OK;
   SHORT Samples[RAWFILE_MAX_CHANNELS];
   if (i64Time < 0)
   {
      while (!IS_RAWERR(hr, RAWERR_NO_MORE_BLOCKS))
         hr = GetNextSampleUnscaled(Samples, m_RawHeader.sNumChannels);
   }
   else
   {
      while ( (m_i64CurElapsedTime < i64Time) && SUCCEEDED(hr))
         hr = GetNextSampleUnscaled(Samples, m_RawHeader.sNumChannels);
   }

   ////////////////////////////////////////////////////////////////////
   // If we hit end of Raw file without reaching desired time, leave there (Or return to original??)
   if (!IS_RAWERR(hr, RAWERR_NO_MORE_BLOCKS) )
      return hr;

   return S_OK;
}


/// Create a new Raw File.
/// Creates a Raw File for Acquisition.
HRESULT P3RawFile::CreateFile(LPCTSTR szFileName)
{
   HRESULT hr;
   if (m_hFile != INVALID_HANDLE_VALUE)
      RETURN_ERR(RAWERR_FILE_ALREADY_OPEN);

   ResetMembers();

   // Save File Name
   m_szFileName = (char*)malloc((strlen(szFileName)+1) * sizeof(char));
   strncpy(m_szFileName, szFileName, strlen(szFileName)+1);

   // Create and Save Jump Name
   m_szJumpName = (char*)malloc((strlen(szFileName)+1) * sizeof(char));
   strncpy(m_szJumpName, szFileName, strlen(szFileName)-3);
   m_szJumpName[strlen(szFileName)-3] = '\0';
   strcat(m_szJumpName, "JMP");

   // Create file
   hr = m_pFileOpener->OpenFile(&m_hFile, szFileName, GENERIC_WRITE | GENERIC_READ, 
                  FILE_SHARE_READ | FILE_SHARE_WRITE, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL);
   if (m_hFile == INVALID_HANDLE_VALUE)
      RETURN_ERR (RAWERR_CANNOT_CREATE_FILE);
   
   // Create jump file
   hr = m_pFileOpener->OpenFile(&m_hJumpFile, m_szJumpName, GENERIC_WRITE | GENERIC_READ, 
                  FILE_SHARE_READ | FILE_SHARE_WRITE, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL);
   if (m_hJumpFile == INVALID_HANDLE_VALUE)
   {
      CloseHandle(m_hFile);
      RETURN_ERR (RAWERR_CANNOT_CREATE_FILE);
   }
   
   // Get Date & time of Raw File
   struct tm *tb1;
   long ldate;
   time(&ldate);
   tb1 = localtime(&ldate);

   ///////////////////////////////////////////////////////////////
   // Set Raw Header to defaults
   m_RawHeader.lFileID = RAWFILE_EXTENDED2;                       // Raw File Type (Always newest type)
   SetFileDate(tb1->tm_year + 1900, tb1->tm_mon + 1, tb1->tm_mday);          // Date
   SetFileTime(tb1->tm_hour, tb1->tm_min, tb1->tm_sec);           // Time
   m_RawHeader.n64JumpTable = 0;                                  // Jump Table
   strcpy(m_RawHeader.szUserName, "");                            // User Name
   m_RawHeader.fRate = 0;                                         // Sample rate
   m_RawHeader.i64TimeSlice = 0;                                  // Time Slice
   m_RawHeader.sAD_Serial = 0;                                    // AD Serial
   m_RawHeader.sCP_Serial = 0;                                    // CP Serial
   m_RawHeader.cGroups = 1;                                       // Number of Groups (Always 1?)
   m_RawHeader.sNumChannels = RAWFILE_MAX_CHANNELS;               // Number of Channels
   m_RawHeader.bOldRawFile = FALSE;
   m_RawHeader.bExtendedFile = TRUE;
   m_RawHeader.bExtendedJump = TRUE;

   // Init divisor counts - all have first sample, divisor set to 1
   for (int iChan=0; iChan < RAWFILE_MAX_CHANNELS; iChan++)
      m_sDivisorCount[iChan] = 1;

   m_iRawFileMode = RAWFILE_WRITING;

   // Initialize Jump Cache if needed
   if (m_pJumpCache == NULL)
      m_pJumpCache = new JumpCache(this);

   return S_OK;
}

HRESULT P3RawFile::PutNextSampleUnscaled(BOOL bSave, short* pSamples, int iCount, float* pSignals)
{
   // If Raw header is invalid, write it out
   if (!m_RawHeader.bValid)
      CHECK_RETURN( WriteRawHeader() );

   // If Block header is not valid and we are supposed to be saving this data, fill block header
   if (!m_BlockHeader.bValid && bSave)
      CHECK_RETURN( FillNextBlockHeader() );

   for (int iChan=0; iChan < m_RawHeader.sNumChannels; iChan++)
   {
      // init vars, if requested
      if (pSignals && iChan < iCount)
         pSignals[iChan] = FLT_MIN;

      char* pDataPos = (m_BlockHeader.pData + m_BlockHeader.dwDataPos);
      // If channel is enabled in RAW
      if (m_RawHeader.acType[iChan])
      {
         // See if Divisor is set to take this channel's sample
         m_sDivisorCount[iChan]--;
         if (m_sDivisorCount[iChan] == 0)
         {
            // Reset Divisor Count
            m_sDivisorCount[iChan] = m_RawHeader.sDivisor[iChan];
            // Save Scaled Sample?
            if (pSignals && pSamples && iChan < iCount)
               pSignals[iChan] = ScaleData(iChan, pSamples[iChan]);
            // Save Data to File?
            if (bSave && pSamples)
            {
               *( (short*)pDataPos ) = pSamples[iChan];
               m_BlockHeader.dwDataPos += 2;
            }
         }
      }
   }
   
   // Advance Time - do this before WriteBlock, that function will subtract the step
   m_i64CurElapsedTime += (INT64)(NANO_FACTOR / m_RawHeader.fRate);

   // If we filled a block, or if we have a partially filled block and saving has stopped, write the block
   if ( (m_BlockHeader.bValid && (m_BlockHeader.dwDataPos >= (DWORD)m_iDesiredBlockSize) ) ||
        (m_BlockHeader.bValid && !bSave) )
      CHECK_RETURN( WriteBlock() );

   return S_OK;
}

HRESULT P3RawFile::PutNextSampleScaled(BOOL bSave, float* pSignals, int iCount, short* pSamples)
{
   short UnscaledData[RAWFILE_MAX_CHANNELS];
   
   // If Raw header is invalid, write it out
   if (!m_RawHeader.bValid)
      CHECK_RETURN( WriteRawHeader() );

   if (bSave && !pSignals)
      return E_INVALIDARG;

   int iMinCount = min(iCount, m_RawHeader.sNumChannels);
   for (int iChan=0; iChan <  iMinCount && pSignals; iChan++)
      UnscaledData[iChan] = UnscaleData(iChan, pSignals[iChan]);

   // Put data in file
   if (pSignals)
   {
      CHECK_RETURN( PutNextSampleUnscaled(bSave, UnscaledData, iMinCount) );
   }
   else
   {
      CHECK_RETURN( PutNextSampleUnscaled(bSave, NULL, iMinCount) );
   }

   // Copy to send back, if requested
   for (iChan=0; iChan < iMinCount && pSignals && pSamples; iChan++)
      pSamples[iChan] = UnscaledData[iChan];

   return S_OK;
}

/// Write the Raw Header to the File - Must call before adding samples to the file
HRESULT P3RawFile::WriteRawHeader()
{
   if (m_hFile == INVALID_HANDLE_VALUE)    
      RETURN_ERR( RAWERR_FILE_NOT_OPEN );

   DWORD dwZero = 0;
   char cOne = 1;
   int iChan;

   CalcScalingVars();

   // Fill out 
   DWORD dwBytes;
   WriteFile(m_hFile, &m_RawHeader.lFileID, 4, &dwBytes, NULL);      // Header ID
   WriteFile(m_hFile, &m_RawHeader.lDate, 4, &dwBytes, NULL);        // Date number
   WriteFile(m_hFile, &m_RawHeader.lTime, 4, &dwBytes, NULL);        // Time number
   
   WriteFile(m_hFile, &dwZero, 4, &dwBytes, NULL);                   // 4byte Jump file location

   // Write User Name
   char szName[USERNAME_LENGTH];
   ZeroMemory(szName, USERNAME_LENGTH);
   strncpy(szName, m_RawHeader.szUserName, USERNAME_LENGTH);
   WriteFile(m_hFile, szName, USERNAME_LENGTH, &dwBytes, NULL);

   // Write Filler Space
   char szFiller[FILLER_LENGTH];
   ZeroMemory(szFiller, FILLER_LENGTH);
   WriteFile(m_hFile, szFiller, FILLER_LENGTH, &dwBytes, NULL);

   DWORD dwTS = (DWORD)(m_RawHeader.i64TimeSlice / (NANO_FACTOR/10000));
   WriteFile(m_hFile, &m_RawHeader.fRate, 4, &dwBytes, NULL);           // Float sample rate
   WriteFile(m_hFile, &dwTS, 4, &dwBytes, NULL);                        // DWORD time slice
   WriteFile(m_hFile, &m_RawHeader.sAD_Serial, 2, &dwBytes, NULL);      // AD Serial
   WriteFile(m_hFile, &m_RawHeader.sCP_Serial, 2, &dwBytes, NULL);      // CP Serial
   WriteFile(m_hFile, &m_RawHeader.cGroups, 1, &dwBytes, NULL);         // Groups
   WriteFile(m_hFile, &m_RawHeader.sNumChannels, 2, &dwBytes, NULL);    // ChannelCount

   for (iChan = 0; iChan < m_RawHeader.sNumChannels; iChan++)
   {
      WriteFile(m_hFile, &m_RawHeader.acType[iChan], 1, &dwBytes, NULL);      // Type
      WriteFile(m_hFile, &m_RawHeader.acDecimal[iChan], 1, &dwBytes, NULL);   // Decimal
      WriteFile(m_hFile, &m_RawHeader.sDivisor[iChan], 2, &dwBytes, NULL);    // Divisor
      WriteFile(m_hFile, &m_RawHeader.afHighCal[iChan], 4, &dwBytes, NULL);   // High Cal
      WriteFile(m_hFile, &m_RawHeader.afLowCal[iChan], 4, &dwBytes, NULL);    // Low Cal
   }
   
   for (iChan = 0; iChan < m_RawHeader.sNumChannels; iChan++)
   {
      WriteFile(m_hFile, &m_RawHeader.Group[0][iChan].AD_High, 2, &dwBytes, NULL);   // AD High
      WriteFile(m_hFile, &m_RawHeader.Group[0][iChan].AD_Low, 2, &dwBytes, NULL);    // AD Low
      WriteFile(m_hFile, &m_RawHeader.Group[0][iChan].Scale, 4, &dwBytes, NULL);     // Scale
      WriteFile(m_hFile, &m_RawHeader.Group[0][iChan].ChanID, 9, &dwBytes, NULL);    // Channel ID
   }

   // Calculate desired block size
   int iBytesPerSecond = 0;
   for (iChan=0; iChan < m_RawHeader.sNumChannels; iChan++)
      if (m_RawHeader.acType[iChan])
         iBytesPerSecond += (int)(m_RawHeader.fRate / m_RawHeader.sDivisor[iChan]) * 2;
   if (iBytesPerSecond < MAX_BLOCK_SIZE)
      m_iDesiredBlockSize = iBytesPerSecond;
   else
      m_iDesiredBlockSize = MAX_BLOCK_SIZE - (m_RawHeader.sNumChannels*2);

   m_RawHeader.bValid = TRUE;

   return S_OK;
}


/// Prep the block header for the next block of data.
HRESULT P3RawFile::FillNextBlockHeader()
{
   m_BlockHeader.dwElapsedTime = (DWORD)(m_i64CurElapsedTime / NANO_FACTOR);
   m_BlockHeader.dwNanoSeconds = (DWORD)(m_i64CurElapsedTime % NANO_FACTOR);
   m_BlockHeader.dwDataSize = 0;
   m_BlockHeader.dwDataPos = 0;
   m_BlockHeader.cGroup = 0;

   // Divisor Count
   for (int iChan=0; iChan < RAWFILE_MAX_CHANNELS; iChan++)
      m_BlockHeader.sDivisorCount[iChan] = m_sDivisorCount[iChan];

   m_BlockHeader.cFirstChan = 0;

   if (m_BlockHeader.pData == NULL)
      m_BlockHeader.pData = (CHAR*)malloc(MAX_BLOCK_SIZE);

   m_BlockHeader.bValid = TRUE;

   return S_OK;
}

/// Write the currently filled block header to the file.
HRESULT P3RawFile::WriteBlock()
{
   DWORD dwBytes;
   m_BlockHeader.i64EndBlockTime = m_i64CurElapsedTime - (INT64)(NANO_FACTOR / m_RawHeader.fRate);

   // Jump file
   char szJumpLine[MAX_PATH];
   szJumpLine[0] = BLOCK_TIME_MARKER;

   int iBlockOffset = 1;
   UINT64 n64Position = HugeSeek(0, FILE_CURRENT);
   INT64 i64BlockTime = (INT64)(m_BlockHeader.dwElapsedTime * (INT64)NANO_FACTOR) + m_BlockHeader.dwNanoSeconds;

   memcpy(&szJumpLine[iBlockOffset], &i64BlockTime, sizeof(INT64));
   iBlockOffset += sizeof(INT64);
   memcpy(&szJumpLine[iBlockOffset], &m_BlockHeader.i64EndBlockTime, sizeof(INT64));
   iBlockOffset += sizeof(INT64);
   memcpy(&szJumpLine[iBlockOffset], &n64Position, sizeof(INT64));
   iBlockOffset += sizeof(INT64);

   WriteFile(m_hJumpFile, szJumpLine, iBlockOffset, &dwBytes, NULL);
   
   // Write Time
   WriteFile(m_hFile, &m_BlockHeader.dwElapsedTime, 4, &dwBytes, NULL);
   WriteFile(m_hFile, &m_BlockHeader.dwNanoSeconds, 4, &dwBytes, NULL);
   WriteFile(m_hFile, &m_BlockHeader.i64EndBlockTime, sizeof(INT64), &dwBytes, NULL);

   // Data size
   WriteFile(m_hFile, &m_BlockHeader.dwDataPos, 4, &dwBytes, NULL);
   WriteFile(m_hFile, &m_BlockHeader.cGroup, 1, &dwBytes, NULL);

   // Divisors
   for (int iChan=0; iChan < m_RawHeader.sNumChannels; iChan++)
      WriteFile(m_hFile, &m_BlockHeader.sDivisorCount[iChan], 2, &dwBytes, NULL);

   // First Chan
   WriteFile(m_hFile, &m_BlockHeader.cFirstChan, 1, &dwBytes, NULL);

   // Data
   WriteFile(m_hFile, m_BlockHeader.pData, m_BlockHeader.dwDataPos, &dwBytes, NULL);

   m_BlockHeader.bValid = FALSE;

   return S_OK;
}

HRESULT P3RawFile::BreakToTime(INT64 i64Time)
{
   // Cant break to previous time
   if (i64Time < m_i64CurElapsedTime)
      return E_INVALIDARG;

   // Breaking to current time will do nothing
   if (i64Time == m_i64CurElapsedTime)
      return S_OK;

   // If we have valid data in a block header, write it out
   if (m_BlockHeader.bValid)
      CHECK_RETURN( WriteBlock() );

   // Advance Time
   m_i64CurElapsedTime = i64Time;

   return S_OK;
}


HRESULT P3RawFile::CalculateDataTimes(INT64 *pStartTimes, INT64 *pEndTimes, int *pCount)
{
   int iEntry;
   if ( !DoesJumpExist() )
      RETURN_ERR( RAWERR_NO_JUMP );

   FILETIME ftLastWrite;
   ::GetFileTime(m_hFile, NULL, NULL, &ftLastWrite);

   //////////////////////////////////////////////////////////////////////////////////////
   // If a change has been made since last CalcDataTimes, or dirst time through, run through jummp file
   if (CompareFileTime(&m_ftLastCalcData, &ftLastWrite) != 0)
   {
      //////////////////////////////////////////////////////////////////////////////////////
      HugeSeek(m_RawHeader.n64RawHeaderLength, FILE_BEGIN);
      CHECK_RETURN( ReadBlockHeader(FALSE) );

      // Cache all entries in the jump file
      m_pJumpCache->Jump(-1);

      //////////////////////////////////////////////////////////////////////////////////////
      // Cycle through and update the Cache with Block Sizes (only if prior to EXTENDED2)
      if (m_RawHeader.lFileID != RAWFILE_EXTENDED2)
      {
         for (iEntry=0; iEntry < m_pJumpCache->GetCacheCount(); iEntry++)
         {
            JMPTBL_ENTRY JmpEntry;
            m_pJumpCache->GetTableEntry(iEntry, &JmpEntry);
      
            // Jump to block and read header
            HugeSeek(JmpEntry.n64FilePos, FILE_BEGIN);
            ReadBlockHeader(FALSE);
            JmpEntry.i64StartTime = m_i64CurElapsedTime;
            JmpEntry.n64BlockSize = m_BlockHeader.dwDataSize;
            m_pJumpCache->CalcBlockEndTime(&JmpEntry, m_BlockHeader.sDivisorCount);
      
            // Pass block info back to JumpCache (will calculate block end time, as well)
            m_pJumpCache->SetTableEntryInfo(iEntry, &JmpEntry);
         }
      }

      //////////////////////////////////////////////////////////////////////////////////////
      // Create SegTimes arrays
      m_iDataTimeCount = 0;
      
      INT64 i64NextStartTime = -1;
      INT64 i64NextEndTime = -1;
      
      for (iEntry=0; iEntry < m_pJumpCache->GetCacheCount(); iEntry++)
      {
         JMPTBL_ENTRY JmpEntry;
         m_pJumpCache->GetTableEntry(iEntry, &JmpEntry);
      
         // Use adjusted times, account for error in raw file times
         INT64 i64EntryStart = JmpEntry.i64StartTime + JmpEntry.i64ErrOffset;
         INT64 i64EntryEnd = JmpEntry.i64EndTime + JmpEntry.i64ErrOffset;
      
         // Set start and end time if this is first block in segment
         if (i64NextStartTime < 0)
         {
            i64NextStartTime = i64EntryStart;
         }
         // otherwise, see if there is a break between this and the previous block
         else if ( (i64NextEndTime + m_RawHeader.i64TimeSlice) < i64EntryStart)
         {
            if (m_iDataTimeCount >= m_iDataTimeAlloc)
            {
               m_iDataTimeAlloc += 20;
               m_pDataStartTimeArray = (INT64*)realloc(m_pDataStartTimeArray, sizeof(INT64)*m_iDataTimeAlloc);
               m_pDataEndTimeArray = (INT64*)realloc(m_pDataEndTimeArray, sizeof(INT64)*m_iDataTimeAlloc);
            }
            // Add previous segment and start new segment
            m_pDataStartTimeArray[m_iDataTimeCount] = i64NextStartTime;
            m_pDataEndTimeArray[m_iDataTimeCount] = i64NextEndTime;
      
            i64NextStartTime = i64EntryStart;
            m_iDataTimeCount++;
         }
         // Always set end time
         i64NextEndTime = i64EntryEnd;
      }

      // Add last segment
      if (i64NextStartTime != -1 && i64NextEndTime != -1)
      {
         if (m_iDataTimeCount >= m_iDataTimeAlloc)
         {
            m_iDataTimeAlloc += 20;
            m_pDataStartTimeArray = (INT64*)realloc(m_pDataStartTimeArray, sizeof(INT64)*m_iDataTimeAlloc);
            m_pDataEndTimeArray = (INT64*)realloc(m_pDataEndTimeArray, sizeof(INT64)*m_iDataTimeAlloc);
         }
         // Add previous segment and start new segment
         m_pDataStartTimeArray[m_iDataTimeCount] = i64NextStartTime;
         m_pDataEndTimeArray[m_iDataTimeCount] = i64NextEndTime;
      
         m_iDataTimeCount++;
      }
      
      m_ftLastCalcData = ftLastWrite;
   }


   ////////////////////////////////////////
   // Copy stored arrays to parameter arrays
   for (iEntry=0; iEntry < min(m_iDataTimeCount, *pCount); iEntry++)
   {
      pStartTimes[iEntry] = m_pDataStartTimeArray[iEntry];
      pEndTimes[iEntry] = m_pDataEndTimeArray[iEntry];
   }

   if (*pCount < m_iDataTimeCount)
   {
      *pCount = m_iDataTimeCount;
      return E_FAIL;
   }

   *pCount = m_iDataTimeCount;
   return S_OK;
}

long P3RawFile::GetRawHeaderID()
{
   return m_RawHeader.lFileID;
}